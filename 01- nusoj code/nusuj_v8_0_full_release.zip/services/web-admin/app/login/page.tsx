
'use client';
export default function Login(){
  const issuer = process.env.NEXT_PUBLIC_KEYCLOAK_ISSUER || process.env.KEYCLOAK_ISSUER;
  const clientId = process.env.NEXT_PUBLIC_KEYCLOAK_CLIENT_ID_ADMIN || process.env.KEYCLOAK_CLIENT_ID_ADMIN;
  const redirect = (process as any).env.ADMIN_BASE_URL + '/oidc/callback';
  const auth = issuer + '/protocol/openid-connect/auth' +
    `?client_id=${encodeURIComponent(clientId)}` +
    `&redirect_uri=${encodeURIComponent(redirect)}` +
    `&response_type=code&scope=openid profile email`;
  return (<main style={{padding:32}}><h1>تسجيل الدخول — لوحة نُسُج</h1><a href={auth}>الدخول عبر Keycloak</a></main>);
}
