
import { NextResponse } from 'next/server';
export function middleware(req: Request) {
  const url = new URL(req.url);
  if (!url.pathname.startsWith('/login') && !url.pathname.startsWith('/public')) {
    const token = (req as any).headers.get('authorization') || (req as any).cookies?.get?.('id_token')?.value;
    if (!token) return NextResponse.redirect(new URL('/login', url.origin));
  }
  return NextResponse.next();
}
