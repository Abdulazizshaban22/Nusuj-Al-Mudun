
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
def morans_i(values):
  n = len(values); m = sum(values)/max(1,n)
  if n < 3: return 0.0
  num = sum((v-m)*(values[(i+1)%n]-m) for i,v in enumerate(values))
  den = sum((v-m)**2 for v in values) or 1.0
  return (n/(n-1))*(num/den)
class H(BaseHTTPRequestHandler):
  def do_POST(self):
    if self.path == '/ai/twin/nowcast':
      ln = int(self.headers.get('content-length','0')); data = json.loads(self.rfile.read(ln) or b'{}')
      series = data.get('series',[1,2,1,3,2,5,2])
      score = morans_i(series[-12:])
      out = json.dumps({"ok":True,"moran":score,"nowcast":series[-1]}).encode()
      self.send_response(200); self.send_header('content-type','application/json'); self.end_headers(); self.wfile.write(out)
    else: self.send_response(404); self.end_headers()
def run(): HTTPServer(('',5005), H).serve_forever()
if __name__=='__main__': run()
