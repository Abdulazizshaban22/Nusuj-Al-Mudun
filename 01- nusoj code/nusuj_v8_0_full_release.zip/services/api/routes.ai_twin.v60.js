
import express from 'express';
import fetch from 'node-fetch';
const router = express.Router();
const AI_TWIN_BASE = process.env.AI_TWIN_BASE || 'http://ai-twin:5005';
router.post('/ai/twin/nowcast', async (req,res)=>{
  try{
    const r = await fetch(`${AI_TWIN_BASE}/ai/twin/nowcast`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(req.body||{}) });
    res.json(await r.json());
  }catch(e){ res.status(500).json({error:String(e)}); }
});
export default router;
