
// Example Express middleware to enforce OIDC on protected routes
import { verifyBearer } from './auth.oidc.js';
export function requireAuth(req, res, next){
  const open = [/^\/ogc\/collections\//, /^\/stac\//, /^\/open311\/requests\//]; // public GETs
  if (open.some(rx => rx.test(req.path)) && req.method === 'GET') return next();
  const auth = req.headers['authorization'];
  verifyBearer(auth).then(()=>next()).catch(()=>res.status(401).json({error:'unauthorized'}));
}
