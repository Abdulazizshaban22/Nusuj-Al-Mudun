
import jwksClient from 'jwks-rsa';
import jwt from 'jsonwebtoken';
const ISSUER = process.env.KEYCLOAK_ISSUER;
const JWKS_URI = `${ISSUER}/protocol/openid-connect/certs`;
const client = jwksClient({ jwksUri: JWKS_URI });
function getKey(header:any, cb:any){ client.getSigningKey(header.kid, (err, key:any)=> cb(err, key?.getPublicKey())); }
export function verifyBearer(authHeader?:string): Promise<any>{
  return new Promise((resolve, reject)=>{
    if(!authHeader) return reject(new Error('no auth'));
    const token = authHeader.replace(/^Bearer\s+/i,'');
    jwt.verify(token, getKey, { algorithms:['RS256'], issuer: ISSUER }, (err, decoded)=> err? reject(err): resolve(decoded));
  });
}
