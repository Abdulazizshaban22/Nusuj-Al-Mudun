
export default function NafathInfo(){
  return (<main style={{padding:16}}>
    <h2>الدخول عبر نفاذ الوطني</h2>
    <p>يتطلب ربطًا رسميًا واعتمادًا من الجهة المختصة. سيتم تفعيل الزر بعد الاعتماد.</p>
  </main>);
}
