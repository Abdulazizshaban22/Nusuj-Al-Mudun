
resource "aws_s3_bucket" "cdn" {
  bucket = replace(var.domain_cdn, ".", "-")
}

resource "aws_cloudfront_origin_access_control" "oac" {
  provider                           = aws.use1
  name                               = "${var.project}-oac"
  origin_access_control_origin_type  = "s3"
  signing_behavior                   = "always"
  signing_protocol                   = "sigv4"
}

# Security headers policy (CSP/HSTS/Referrer)
resource "aws_cloudfront_response_headers_policy" "security" {
  provider = aws.use1
  name     = "${var.project}-security-headers"
  security_headers_config {
    content_security_policy {
      content_security_policy = "default-src 'self'; img-src 'self' data: https:; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self' https:;"
      override                = true
    }
    strict_transport_security {
      access_control_max_age_sec = 31536000
      include_subdomains         = true
      preload                    = true
      override                   = true
    }
    referrer_policy {
      referrer_policy = "no-referrer"
      override        = true
    }
    x_content_type_options { override = true }
    x_frame_options       { frame_option = "DENY" override = true }
  }
}

resource "aws_cloudfront_distribution" "cdn" {
  enabled         = true
  aliases         = [var.domain_cdn]

  origin {
    domain_name              = aws_s3_bucket.cdn.bucket_regional_domain_name
    origin_id                = "s3-origin"
    origin_access_control_id = aws_cloudfront_origin_access_control.oac.id
  }

  default_cache_behavior {
    allowed_methods        = ["GET", "HEAD"]
    cached_methods         = ["GET", "HEAD"]
    target_origin_id       = "s3-origin"
    viewer_protocol_policy = "redirect-to-https"
    compress               = true
    response_headers_policy_id = aws_cloudfront_response_headers_policy.security.id
  }

  viewer_certificate {
    acm_certificate_arn = aws_acm_certificate.cf.arn
    ssl_support_method  = "sni-only"
    minimum_protocol_version = "TLSv1.2_2021"
  }

  restrictions { geo_restriction { restriction_type = "none" } }
}
