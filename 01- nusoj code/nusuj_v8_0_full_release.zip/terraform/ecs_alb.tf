
resource "aws_ecs_cluster" "this" {
  name = "${var.project}-cluster"
}

resource "aws_cloudwatch_log_group" "ecs" {
  name              = "/ecs/${var.project}"
  retention_in_days = 30
}

# ALB
resource "aws_lb" "web" {
  name               = "${var.project}-alb"
  load_balancer_type = "application"
  security_groups    = [] # TODO: SG id list
  subnets            = var.public_subnets
}

resource "aws_lb_target_group" "tg_admin" {
  name        = "${var.project}-tg-admin"
  port        = 3000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id
  health_check { path = "/" }
}

resource "aws_lb_target_group" "tg_citizen" {
  name        = "${var.project}-tg-citizen"
  port        = 3000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id
  health_check { path = "/" }
}

resource "aws_lb_target_group" "tg_api" {
  name        = "${var.project}-tg-api"
  port        = 4000
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id
  health_check { path = "/health" }
}

resource "aws_lb_target_group" "tg_ai_twin" {
  name        = "${var.project}-tg-aitwin"
  port        = 5005
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = var.vpc_id
  health_check { path = "/ai/twin/nowcast" }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.web.arn
  port              = 443
  protocol          = "HTTPS"
  certificate_arn   = aws_acm_certificate.alb.arn
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.tg_citizen.arn
  }
}

# Host routing (admin/citizen)
resource "aws_lb_listener_rule" "host_admin" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 10
  action { type = "forward" target_group_arn = aws_lb_target_group.tg_admin.arn }
  condition { host_header { values = [var.domain_admin] } }
}

resource "aws_lb_listener_rule" "host_citizen" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 20
  action { type = "forward" target_group_arn = aws_lb_target_group.tg_citizen.arn }
  condition { host_header { values = [var.domain_citizen] } }
}

# Path routing for API & AI-Twin under both hosts
resource "aws_lb_listener_rule" "path_api" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 30
  action { type = "forward" target_group_arn = aws_lb_target_group.tg_api.arn }
  condition { path_pattern { values = ["/api*", "/ogc*", "/open311*", "/stac*"] } }
}

resource "aws_lb_listener_rule" "path_aitwin" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 40
  action { type = "forward" target_group_arn = aws_lb_target_group.tg_ai_twin.arn }
  condition { path_pattern { values = ["/ai*", "/twin*"] } }
}

# WAF association
resource "aws_wafv2_web_acl_association" "alb_assoc" {
  resource_arn = aws_lb.web.arn
  web_acl_arn  = aws_wafv2_web_acl.alb.arn
}

# Route53 records
resource "aws_route53_record" "admin" {
  zone_id = var.hosted_zone_id
  name    = var.domain_admin
  type    = "A"
  alias {
    name                   = aws_lb.web.dns_name
    zone_id                = aws_lb.web.zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_record" "citizen" {
  zone_id = var.hosted_zone_id
  name    = var.domain_citizen
  type    = "A"
  alias {
    name                   = aws_lb.web.dns_name
    zone_id                = aws_lb.web.zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_record" "cdn" {
  zone_id = var.hosted_zone_id
  name    = var.domain_cdn
  type    = "A"
  alias {
    name                   = aws_cloudfront_distribution.cdn.domain_name
    zone_id                = aws_cloudfront_distribution.cdn.hosted_zone_id
    evaluate_target_health = false
  }
}

# IAM roles
data "aws_iam_policy_document" "task_assume" {
  statement { actions = ["sts:AssumeRole"] principals { type = "Service" identifiers = ["ecs-tasks.amazonaws.com"] } }
}
resource "aws_iam_role" "task" { name = "${var.project}-task" assume_role_policy = data.aws_iam_policy_document.task_assume.json }
resource "aws_iam_role" "task_exec" { name = "${var.project}-task-exec" assume_role_policy = data.aws_iam_policy_document.task_assume.json }

# Task defs
resource "aws_ecs_task_definition" "api" {
  family                   = "${var.project}-api"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.cpu
  memory                   = var.memory
  execution_role_arn       = aws_iam_role.task_exec.arn
  task_role_arn            = aws_iam_role.task.arn
  container_definitions    = jsonencode([{
    name: "api",
    image: var.api_image,
    portMappings: [{containerPort:4000,hostPort:4000}],
    essential: true,
    environment: [ for k,v in var.env_api : { name: k, value: v } ],
    logConfiguration: { logDriver:"awslogs", options:{ awslogs-group: aws_cloudwatch_log_group.ecs.name, awslogs-region: var.region, awslogs-stream-prefix:"api" } }
  }])
}

resource "aws_ecs_task_definition" "admin" {
  family                   = "${var.project}-admin"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.cpu
  memory                   = var.memory
  execution_role_arn       = aws_iam_role.task_exec.arn
  task_role_arn            = aws_iam_role.task.arn
  container_definitions    = jsonencode([{
    name: "web-admin",
    image: var.admin_image,
    portMappings: [{containerPort:3000,hostPort:3000}],
    essential: true,
    environment: [ for k,v in var.env_admin : { name: k, value: v } ],
    logConfiguration: { logDriver:"awslogs", options:{ awslogs-group: aws_cloudwatch_log_group.ecs.name, awslogs-region: var.region, awslogs-stream-prefix:"admin" } }
  }])
}

resource "aws_ecs_task_definition" "citizen" {
  family                   = "${var.project}-citizen"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.cpu
  memory                   = var.memory
  execution_role_arn       = aws_iam_role.task_exec.arn
  task_role_arn            = aws_iam_role.task.arn
  container_definitions    = jsonencode([{
    name: "web-citizen",
    image: var.citizen_image,
    portMappings: [{containerPort:3000,hostPort:3000}],
    essential: true,
    environment: [ for k,v in var.env_citizen : { name: k, value: v } ],
    logConfiguration: { logDriver:"awslogs", options:{ awslogs-group: aws_cloudwatch_log_group.ecs.name, awslogs-region: var.region, awslogs-stream-prefix:"citizen" } }
  }])
}

resource "aws_ecs_task_definition" "ai_twin" {
  family                   = "${var.project}-ai-twin"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.cpu
  memory                   = var.memory
  execution_role_arn       = aws_iam_role.task_exec.arn
  task_role_arn            = aws_iam_role.task.arn
  container_definitions    = jsonencode([{
    name: "ai-twin",
    image: var.ai_twin_image,
    portMappings: [{containerPort:5005,hostPort:5005}],
    essential: true,
    environment: [ for k,v in var.env_ai_twin : { name: k, value: v } ],
    logConfiguration: { logDriver:"awslogs", options:{ awslogs-group: aws_cloudwatch_log_group.ecs.name, awslogs-region: var.region, awslogs-stream-prefix:"ai-twin" } }
  }])
}

# Services
resource "aws_ecs_service" "api" {
  name            = "${var.project}-api"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.api.arn
  desired_count   = var.desired_api
  launch_type     = "FARGATE"
  network_configuration { assign_public_ip = false subnets = var.private_subnets security_groups = [] }
  load_balancer { target_group_arn = aws_lb_target_group.tg_api.arn container_name = "api" container_port = 4000 }
  depends_on = [aws_lb_listener.https]
}

resource "aws_ecs_service" "admin" {
  name            = "${var.project}-admin"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.admin.arn
  desired_count   = var.desired_admin
  launch_type     = "FARGATE"
  network_configuration { assign_public_ip = false subnets = var.private_subnets security_groups = [] }
  load_balancer { target_group_arn = aws_lb_target_group.tg_admin.arn container_name = "web-admin" container_port = 3000 }
  depends_on = [aws_lb_listener.https]
}

resource "aws_ecs_service" "citizen" {
  name            = "${var.project}-citizen"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.citizen.arn
  desired_count   = var.desired_citizen
  launch_type     = "FARGATE"
  network_configuration { assign_public_ip = false subnets = var.private_subnets security_groups = [] }
  load_balancer { target_group_arn = aws_lb_target_group.tg_citizen.arn container_name = "web-citizen" container_port = 3000 }
  depends_on = [aws_lb_listener.https]
}

resource "aws_ecs_service" "ai_twin" {
  name            = "${var.project}-ai-twin"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.ai_twin.arn
  desired_count   = var.desired_ai_twin
  launch_type     = "FARGATE"
  network_configuration { assign_public_ip = false subnets = var.private_subnets security_groups = [] }
  load_balancer { target_group_arn = aws_lb_target_group.tg_ai_twin.arn container_name = "ai-twin" container_port = 5005 }
  depends_on = [aws_lb_listener.https]
}
