
output "alb_dns_name"        { value = aws_lb.web.dns_name }
output "cloudfront_domain"   { value = aws_cloudfront_distribution.cdn.domain_name }
output "ecs_cluster"         { value = aws_ecs_cluster.this.name }
output "tg_api"              { value = aws_lb_target_group.tg_api.arn }
output "tg_admin"            { value = aws_lb_target_group.tg_admin.arn }
output "tg_citizen"          { value = aws_lb_target_group.tg_citizen.arn }
output "tg_ai_twin"          { value = aws_lb_target_group.tg_ai_twin.arn }
