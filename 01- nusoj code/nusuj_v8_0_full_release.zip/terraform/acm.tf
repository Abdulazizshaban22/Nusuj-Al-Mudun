
# CloudFront cert (must be in us-east-1)
resource "aws_acm_certificate" "cf" {
  provider          = aws.use1
  domain_name       = var.domain_cdn
  validation_method = "DNS"
}

# ALB cert (regional) for admin & citizen
resource "aws_acm_certificate" "alb" {
  domain_name               = var.domain_admin
  subject_alternative_names = [var.domain_citizen]
  validation_method         = "DNS"
}

data "aws_route53_zone" "zone" {
  zone_id = var.hosted_zone_id
}

# DNS validation records
resource "aws_route53_record" "alb_validation_admin" {
  for_each = { for dvo in aws_acm_certificate.alb.domain_validation_options : dvo.domain_name => { name = dvo.resource_record_name, type = dvo.resource_record_type, value = dvo.resource_record_value } }
  zone_id = data.aws_route53_zone.zone.zone_id
  name    = each.value.name
  type    = each.value.type
  ttl     = 60
  records = [each.value.value]
}

resource "aws_acm_certificate_validation" "alb_validation" {
  certificate_arn         = aws_acm_certificate.alb.arn
  validation_record_fqdns = [for r in aws_route53_record.alb_validation_admin : r.fqdn]
}

resource "aws_route53_record" "cf_validation" {
  for_each = { for dvo in aws_acm_certificate.cf.domain_validation_options : dvo.domain_name => { name = dvo.resource_record_name, type = dvo.resource_record_type, value = dvo.resource_record_value } }
  zone_id = data.aws_route53_zone.zone.zone_id
  name    = each.value.name
  type    = each.value.type
  ttl     = 60
  records = [each.value.value]
}

resource "aws_acm_certificate_validation" "cf_validation" {
  provider                = aws.use1
  certificate_arn         = aws_acm_certificate.cf.arn
  validation_record_fqdns = [for r in aws_route53_record.cf_validation : r.fqdn]
}
