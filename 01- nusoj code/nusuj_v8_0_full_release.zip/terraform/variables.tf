
variable "project"           { type = string  default = "nusuj" }
variable "region"            { type = string  default = "me-central-1" }
variable "hosted_zone_id"    { type = string }
variable "domain_admin"      { type = string  default = "admin.nusuj.sa" }
variable "domain_citizen"    { type = string  default = "citizen.nusuj.sa" }
variable "domain_cdn"        { type = string  default = "cdn.nusuj.sa" }

# Network
variable "vpc_id"            { type = string }
variable "public_subnets"    { type = list(string) }
variable "private_subnets"   { type = list(string) }

# Images (ECR URIs or docker hub)
variable "api_image"         { type = string  default = "YOUR_ECR/account/nusuj-api:latest" }
variable "admin_image"       { type = string  default = "YOUR_ECR/account/nusuj-admin:latest" }
variable "citizen_image"     { type = string  default = "YOUR_ECR/account/nusuj-citizen:latest" }
variable "ai_twin_image"     { type = string  default = "YOUR_ECR/account/nusuj-ai-twin:latest" }

# ECS sizing
variable "cpu"               { type = number  default = 512 }
variable "memory"            { type = number  default = 1024 }
variable "desired_admin"     { type = number  default = 2 }
variable "desired_citizen"   { type = number  default = 2 }
variable "desired_api"       { type = number  default = 2 }
variable "desired_ai_twin"   { type = number  default = 1 }

# Env
variable "env_api"           { type = map(string)  default = {} }
variable "env_admin"         { type = map(string)  default = {} }
variable "env_citizen"       { type = map(string)  default = {} }
variable "env_ai_twin"       { type = map(string)  default = {} }
