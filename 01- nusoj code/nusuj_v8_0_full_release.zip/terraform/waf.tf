
# Global WAF for CloudFront
resource "aws_wafv2_web_acl" "cf" {
  provider = aws.use1
  name  = "${var.project}-cf-waf"
  scope = "CLOUDFRONT"
  default_action { allow {} }
  visibility_config { cloudwatch_metrics_enabled = true metric_name = "cf-waf" sampled_requests_enabled = true }

  rule {
    name     = "ManagedCommon"
    priority = 1
    statement { managed_rule_group_statement { name = "AWSManagedRulesCommonRuleSet" vendor_name = "AWS" } }
    override_action { none {} }
    visibility_config { cloudwatch_metrics_enabled = true metric_name = "cf-common" sampled_requests_enabled = true }
  }

  rule {
    name     = "RateLimit"
    priority = 2
    statement { rate_based_statement { limit = 1000 aggregate_key_type = "IP" } }
    visibility_config { cloudwatch_metrics_enabled = true metric_name = "cf-rate" sampled_requests_enabled = true }
    override_action { none {} }
  }
}

# Regional WAF for ALB
resource "aws_wafv2_web_acl" "alb" {
  name  = "${var.project}-alb-waf"
  scope = "REGIONAL"
  default_action { allow {} }
  visibility_config { cloudwatch_metrics_enabled = true metric_name = "alb-waf" sampled_requests_enabled = true }

  rule {
    name     = "ManagedCommon"
    priority = 1
    statement { managed_rule_group_statement { name = "AWSManagedRulesCommonRuleSet" vendor_name = "AWS" } }
    override_action { none {} }
    visibility_config { cloudwatch_metrics_enabled = true metric_name = "alb-common" sampled_requests_enabled = true }
  }

  rule {
    name     = "RateLimit"
    priority = 2
    statement { rate_based_statement { limit = 2000 aggregate_key_type = "IP" } }
    visibility_config { cloudwatch_metrics_enabled = true metric_name = "alb-rate" sampled_requests_enabled = true }
    override_action { none {} }
  }
}
