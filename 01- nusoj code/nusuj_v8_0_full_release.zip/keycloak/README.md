
# Keycloak Realm — nusuj
1) Import `realm-nusuj.json` (Admin Console → Realm settings → Import) أو عبر `kcadm.sh` partialImport.
2) أضف Valid Redirect URIs: 
   - https://admin.nusuj.sa/* 
   - https://citizen.nusuj.sa/*
3) عيّن الأدوار realm roles: admin / municipality / analyst / citizen حسب الحسابات.
