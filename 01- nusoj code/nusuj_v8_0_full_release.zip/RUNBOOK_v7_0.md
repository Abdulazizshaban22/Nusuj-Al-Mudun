
# v7.0 — Institutional Integrations
1) استلم مفاتيح الوصول من NDB/GASTAT/Balady.
2) حدّد جداول الربط مع Open311 والخدمات.
3) شغّل سكربتات connectors لتغذية قاعدة البيانات والمؤشرات.
