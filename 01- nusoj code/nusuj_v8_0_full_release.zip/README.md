
# NUSUJ v7.5 — Prod Wire‑up 2

يشمل:
- Terraform: ACM/CloudFront+OAC/WAF/ALB/Route53
- Keycloak Realm جاهز (admin/citizen) + توجيهات نفاذ
- ETL موحّد لـ GASTAT/بلدي → KPIs
- StoryMaps مثال جودة الحياة
