
import fetch from 'node-fetch';
const API = process.env.BALADY_API || 'https://apiservices.balady.gov.sa/v1/momrah-...';
(async ()=>{ const r = await fetch(API); const j = await r.json(); console.log('sample', Array.isArray(j)? j.slice(0,2) : j); })().catch(console.error);
