
import fs from 'fs'; import fetch from 'node-fetch';
const STAC = process.env.STAC_SEARCH || 'http://localhost:4000/stac/search';
(async ()=>{
  const body = { collections:['ndvi'], bbox:[40,16,55,33], datetime:'2025-01-01/2025-12-31', limit:20 };
  const r = await fetch(STAC, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(body)});
  const j = await r.json(); fs.writeFileSync('stac_ndvi.json', JSON.stringify(j,null,2));
  console.log('saved stac_ndvi.json', (j.features?.length||j.items?.length||0));
})().catch(console.error);
