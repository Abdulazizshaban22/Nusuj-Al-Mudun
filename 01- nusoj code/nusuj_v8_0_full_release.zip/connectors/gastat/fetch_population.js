
import fs from 'fs'; import fetch from 'node-fetch';
const URL = process.env.GASTAT_POP_URL || 'https://example/stats.csv';
(async ()=>{ const r = await fetch(URL); const t = await r.text(); fs.writeFileSync('population.csv', t); console.log('saved population.csv'); })().catch(console.error);
