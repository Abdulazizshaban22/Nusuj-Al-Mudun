
# NUSUJ v8.0 — Full Release (Unified)

يتضمن هذا الإصدار كل ما تحتاجه للإطلاق:
- Terraform (v7.6) — ECS/ALB/CloudFront/OAC/WAF/ACM/Route53
- Scripts (v7.7) — go-live / check-acm / update-ecs / bootstrap-keycloak / seed-kpis
- Keycloak Realm + Nafath guide (v7.5)
- AI‑Twin Service + API routes (v6.0)
- Institutional Connectors (GASTAT/Balady/STAC) (v7.0)
- Identity/Domain helpers + OIDC JWKS (v5.5)

## Quick Start
1) حرّر `golive.tfvars` بقيم الشبكة والنطاقات وصور الـECR.
2) نفّذ:
   ```bash
   bash scripts/go-live.sh ./golive.tfvars
   ```
3) استورد Realm في Keycloak:
   ```bash
   bash scripts/bootstrap-keycloak.sh
   ```
4) غذِّ KPIs:
   ```bash
   bash scripts/seed-kpis.sh
   ```
5) اختبر النطاقات:
   - https://admin.nusuj.sa
   - https://citizen.nusuj.sa
   - https://admin.nusuj.sa/api/*
   - https://admin.nusuj.sa/ai/twin/nowcast
   - https://cdn.nusuj.sa
