
import csv, sys, json

def run(inp_csv, out_json='kpi_population.json'):
  # expects columns: region_code, region_name, year, population_total
  by_region = {}
  with open(inp_csv, newline='', encoding='utf-8') as f:
    r = csv.DictReader(f)
    for row in r:
      k = (row['region_code'], row.get('year'))
      by_region[k] = int(row['population_total'])
  kpis = [{"k":"pop_total","dim":{"region":rc,"year":yr},"v":v} for (rc,yr),v in by_region.items()]
  with open(out_json,'w',encoding='utf-8') as f: json.dump(kpis,f,ensure_ascii=False,indent=2)
  print("Wrote", out_json, "items:", len(kpis))

if __name__ == "__main__":
  if len(sys.argv)<2:
    print("usage: python gastat_to_kpi.py population.csv"); sys.exit(1)
  run(sys.argv[1])
