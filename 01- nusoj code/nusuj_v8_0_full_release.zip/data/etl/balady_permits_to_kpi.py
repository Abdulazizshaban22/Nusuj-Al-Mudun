
# Convert Balady open-data (building permits, violations, etc.) to KPI series
import csv, sys, json, datetime as dt

def run(inp_csv, out_json='kpi_permits.json'):
  out = []
  with open(inp_csv, newline='', encoding='utf-8') as f:
    r = csv.DictReader(f)
    for row in r:
      out.append({
        "k":"permits_count",
        "t": row.get("issue_date") or row.get("date"),
        "dim": {"municipality": row.get("municipality_name")},
        "v": 1
      })
  with open(out_json,'w',encoding='utf-8') as f: json.dump(out,f,ensure_ascii=False,indent=2)
  print("Wrote", out_json, "items:", len(out))

if __name__ == "__main__":
  if len(sys.argv)<2:
    print("usage: python balady_permits_to_kpi.py balady_permits.csv"); sys.exit(1)
  run(sys.argv[1])
