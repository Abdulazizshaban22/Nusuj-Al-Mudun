
# v5.5 — الهوية والنطاقات
- OIDC عبر Keycloak (admin/citizen).
- استعداد ربط نفاذ بعد الاعتماد الرسمي.
- نطاقات الإنتاج: admin.nusuj.sa / citizen.nusuj.sa / cdn.nusuj.sa.
