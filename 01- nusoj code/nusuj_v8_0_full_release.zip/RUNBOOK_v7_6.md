
# NUSUJ v7.6 — Prod Wire‑up 3

## الهدف
- تحويل البنية إلى **خدمات ECS Fargate** خلف **ALB** مع **توجيه Host/Path**.
- تفعيل **ACM DNS Validation** تلقائي و**CloudFront Response Headers Policy** (CSP/HSTS).
- إضافة **WAF** عالمي (CloudFront) وإقليمي (ALB) مع **RateBased** قواعد.
- إصدار **CI/CD** لبناء صور ودفعها إلى ECR وتحديث الخدمات.

## الاستخدام
1) حدّد قيم شبكة الإنتاج:
   ```hcl
   vpc_id          = "vpc-..."
   public_subnets  = ["subnet-...", "subnet-..."]
   private_subnets = ["subnet-...", "subnet-..."]
   hosted_zone_id  = "Z123..."
   ```
2) طبّقterraform:
   ```bash
   cd terraform
   terraform init
   terraform apply      -var='api_image=ACCOUNT.dkr.ecr.REGION.amazonaws.com/nusuj-api:latest'      -var='admin_image=ACCOUNT.dkr.ecr.REGION.amazonaws.com/nusuj-admin:latest'      -var='citizen_image=ACCOUNT.dkr.ecr.REGION.amazonaws.com/nusuj-citizen:latest'      -var='ai_twin_image=ACCOUNT.dkr.ecr.REGION.amazonaws.com/nusuj-ai-twin:latest'
   ```
3) املأ خرائط المتغيرات `env_*` (S3_BUCKET / CF_DOMAIN / KEYCLOAK_ISSUER / VAPID_* ...).
4) بعد نشر الخدمات، سجّل الدخول عبر Keycloak في لوحة **admin.nusuj.sa**، واختبر:
   - مسارات API عبر **/api/** تحت كِلا النطاقين (host routing + path rules).
   - **AI‑Twin** عبر **/ai/twin/nowcast**.
   - ملفات CDN من **cdn.nusuj.sa** (CloudFront + OAC + CSP/HSTS).

> ملاحظة: أضفت **Security Headers** عبر ResponseHeadersPolicy بدل Lambda@Edge — أبسط وأمنح أداءً أعلى.
