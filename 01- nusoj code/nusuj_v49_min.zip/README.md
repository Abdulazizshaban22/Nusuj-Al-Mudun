
# نُسُج — NUSUJ v4.9 (Minimal Deliverable)

- API (Node + Express): `/ogc/conformance`, `/ogc/queryables`, `/ogc/collections/*` (skeleton).
- Web (static HTML): Story preview with MapLibre.

## Run API
```bash
cd services/api
npm i
node index.js
```

## Run Web (static)
- Open `services/web/index.html` in a browser.
