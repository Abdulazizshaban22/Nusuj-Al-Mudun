
import express from 'express';
import bodyParser from 'body-parser';

const app = express();
app.use(bodyParser.json());

app.get('/ogc/conformance', (_req, res) => {
  res.json({
    conformsTo: [
      "http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/core",
      "http://www.opengis.net/spec/ogcapi-features-3/1.0/conf/filter",
      "http://www.opengis.net/spec/cql2/1.0/conf/cql2-text",
      "http://www.opengis.net/spec/cql2/1.0/conf/cql2-json"
    ]
  });
});

app.get('/ogc/queryables', (_req, res) => {
  res.json({
    type: "Queryables",
    properties: {
      class: { "type": "string" },
      score: { "type": "number" },
      status: { "type": "string" }
    }
  });
});

app.get('/ogc/collections', (_req,res)=>{
  res.json({collections:[
    {id:"features", itemType:"feature", title:"General Features"},
    {id:"open311_requests", itemType:"record", title:"Open311 Service Requests"}
  ]});
});

app.listen(4000, ()=> console.log("NUSUJ API (min) on :4000"));
