
variable "region" { type = string  default = "me-central-1" }
variable "hosted_zone_id" { type = string }
variable "domain_admin"  { type = string  default = "admin.nusuj.sa" }
variable "domain_citizen"{ type = string  default = "citizen.nusuj.sa" }
variable "domain_cdn"    { type = string  default = "cdn.nusuj.sa" }
variable "oai_comment"   { type = string  default = "OAC for cdn.nusuj.sa" }

# IDs for optional existing resources
variable "alb_admin_target_arn"   { type = string  default = "" } # if using existing TG
variable "alb_citizen_target_arn" { type = string  default = "" }
