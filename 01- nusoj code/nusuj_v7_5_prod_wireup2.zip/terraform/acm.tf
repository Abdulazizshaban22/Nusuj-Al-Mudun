
# CloudFront requires ACM certs in us-east-1
resource "aws_acm_certificate" "cdn" {
  provider          = aws.use1
  domain_name       = var.domain_cdn
  validation_method = "DNS"
}

# Regional cert for ALB (admin/citizen)
resource "aws_acm_certificate" "alb" {
  domain_name       = var.domain_admin
  subject_alternative_names = [var.domain_citizen]
  validation_method = "DNS"
}
