
resource "aws_s3_bucket" "cdn" {
  bucket = replace(var.domain_cdn, ".", "-")
}

resource "aws_cloudfront_origin_access_control" "oac" {
  name                              = "oac-cdn"
  description                       = var.oai_comment
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

# Minimal WAF (CloudFront scope) with AWS managed rules
resource "aws_wafv2_web_acl" "cf_global" {
  provider = aws.use1
  name        = "nusuj-cf-waf"
  description = "Global WAF for CloudFront"
  scope       = "CLOUDFRONT"
  default_action { allow {} }

  rule {
    name     = "AWS-AWSManagedRulesCommonRuleSet"
    priority = 1
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      cloudwatch_metrics_enabled = true
      metric_name                = "cf-common"
      sampled_requests_enabled   = true
    }
    override_action { none {} }
  }

  visibility_config {
    cloudwatch_metrics_enabled = true
    metric_name                = "cf-waf"
    sampled_requests_enabled   = true
  }
}

resource "aws_cloudfront_distribution" "cdn" {
  enabled             = true
  is_ipv6_enabled     = true
  aliases             = [var.domain_cdn]

  origin {
    domain_name = aws_s3_bucket.cdn.bucket_regional_domain_name
    origin_id   = "s3-cdn"
    origin_access_control_id = aws_cloudfront_origin_access_control.oac.id
  }

  default_cache_behavior {
    allowed_methods  = ["GET", "HEAD"]
    cached_methods   = ["GET", "HEAD"]
    target_origin_id = "s3-cdn"
    viewer_protocol_policy = "redirect-to-https"
    compress = true
  }

  viewer_certificate {
    acm_certificate_arn = aws_acm_certificate.cdn.arn
    ssl_support_method  = "sni-only"
    minimum_protocol_version = "TLSv1.2_2021"
  }

  restrictions {
    geo_restriction { restriction_type = "none" }
  }

  web_acl_id = aws_wafv2_web_acl.cf_global.arn
  price_class = "PriceClass_200"
}
