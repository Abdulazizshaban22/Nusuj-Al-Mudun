
terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

provider "aws" {
  region = var.region
}

# CloudFront/WAF global resources (us-east-1 requirement for ACM/WAF CloudFront)
provider "aws" {
  alias  = "use1"
  region = "us-east-1"
}
