
resource "aws_lb" "web" {
  name               = "nusuj-web"
  load_balancer_type = "application"
  internal           = false
  security_groups    = []
  subnets            = [] # fill your public subnets
}

resource "aws_lb_target_group" "admin" {
  name     = "tg-admin"
  port     = 3000
  protocol = "HTTP"
  vpc_id   = "" # fill with your VPC
  health_check { path = "/" }
}

resource "aws_lb_target_group" "citizen" {
  name     = "tg-citizen"
  port     = 3000
  protocol = "HTTP"
  vpc_id   = "" # fill with your VPC
  health_check { path = "/" }
}

resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.web.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = "ELBSecurityPolicy-TLS13-1-2-2021-06"
  certificate_arn   = aws_acm_certificate.alb.arn

  default_action {
    type = "forward"
    target_group_arn = aws_lb_target_group.citizen.arn
  }
}

# Host-based rules
resource "aws_lb_listener_rule" "admin" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 10
  action { type = "forward" target_group_arn = aws_lb_target_group.admin.arn }
  condition { host_header { values = [var.domain_admin] } }
}

resource "aws_lb_listener_rule" "citizen" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 20
  action { type = "forward" target_group_arn = aws_lb_target_group.citizen.arn }
  condition { host_header { values = [var.domain_citizen] } }
}

# Regional WAF for ALB
resource "aws_wafv2_web_acl" "alb_regional" {
  name  = "nusuj-alb-waf"
  scope = "REGIONAL"
  default_action { allow {} }
  rule {
    name     = "AWS-AWSManagedRulesCommonRuleSet"
    priority = 1
    statement { managed_rule_group_statement { name = "AWSManagedRulesCommonRuleSet" vendor_name = "AWS" } }
    visibility_config { cloudwatch_metrics_enabled = true metric_name = "alb-common" sampled_requests_enabled = true }
    override_action { none {} }
  }
  visibility_config { cloudwatch_metrics_enabled = true metric_name = "alb-waf" sampled_requests_enabled = true }
}

resource "aws_wafv2_web_acl_association" "alb_assoc" {
  resource_arn = aws_lb.web.arn
  web_acl_arn  = aws_wafv2_web_acl.alb_regional.arn
}

# Route53 records
data "aws_route53_zone" "main" { zone_id = var.hosted_zone_id }

resource "aws_route53_record" "admin" {
  zone_id = data.aws_route53_zone.main.zone_id
  name    = var.domain_admin
  type    = "A"
  alias {
    name                   = aws_lb.web.dns_name
    zone_id                = aws_lb.web.zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_record" "citizen" {
  zone_id = data.aws_route53_zone.main.zone_id
  name    = var.domain_citizen
  type    = "A"
  alias {
    name                   = aws_lb.web.dns_name
    zone_id                = aws_lb.web.zone_id
    evaluate_target_health = true
  }
}

resource "aws_route53_record" "cdn" {
  zone_id = data.aws_route53_zone.main.zone_id
  name    = var.domain_cdn
  type    = "A"
  alias {
    name                   = aws_cloudfront_distribution.cdn.domain_name
    zone_id                = aws_cloudfront_distribution.cdn.hosted_zone_id
    evaluate_target_health = false
  }
}
