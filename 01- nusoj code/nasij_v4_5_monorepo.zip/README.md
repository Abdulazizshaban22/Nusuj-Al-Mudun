
# NUSUJ (نُسُج) — v4.5

## ماذا يتضمن هذا الإصدار؟
- OGC API-Features **Extended Filters**: `bbox`, `bbox-crs`, `datetime`, `filter`, `filter-lang=cql2-text` (subset)، `sortby`.
- **Spatio‑Temporal Gi*** (Getis‑Ord) API: `/st/gi_star` لحساب z-scores وp-values على خلايا H3 ضمن نافذة زمنية.
- Terraform مكتمل للنشر السيادي على AWS: **VPC + Subnets + ALB + ACM + ECS Services + Route53**.
- PDPL Evidence Pack (سجل المعالجة + DSR + الحوادث).
