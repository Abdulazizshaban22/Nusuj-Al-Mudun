
# Terraform — نشر NUSUJ v4.5 على AWS
انفّذ:
terraform init
terraform apply -auto-approve   -var='project=nusuj'   -var='aws_region=me-south-1'   -var='domain_name=nusuj.example.sa'   -var='hosted_zone_id=Z123'   -var='acm_certificate_arn=arn:aws:acm:...'   -var='api_image=YOUR_ECR_REPO/api:4.5'   -var='etl_image=YOUR_ECR_REPO/etl:4.5'
