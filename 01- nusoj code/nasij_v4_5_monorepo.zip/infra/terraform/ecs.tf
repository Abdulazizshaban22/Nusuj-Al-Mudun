
resource "aws_ecs_cluster" "this" { name = "${var.project}-cluster" }

resource "aws_iam_role" "task_exec" {
  name = "${var.project}-task-exec"
  assume_role_policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Effect = "Allow",
      Principal = { Service = "ecs-tasks.amazonaws.com" },
      Action = "sts:AssumeRole"
    }]
  })
}
resource "aws_iam_role_policy_attachment" "task_exec_attach" {
  role       = aws_iam_role.task_exec.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_security_group" "svc_sg" {
  name   = "${var.project}-svc-sg"
  vpc_id = aws_vpc.this.id
  ingress { from_port = 4000, to_port = 4000, protocol = "tcp", security_groups = [aws_security_group.alb_sg.id] }
  ingress { from_port = 5000, to_port = 5000, protocol = "tcp", security_groups = [aws_security_group.alb_sg.id] }
  egress  { from_port = 0, to_port = 0, protocol = "-1", cidr_blocks = ["0.0.0.0/0"] }
}

resource "aws_ecs_task_definition" "api" {
  family                   = "${var.project}-api"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = aws_iam_role.task_exec.arn
  container_definitions = jsonencode([{
    name  = "api",
    image = var.api_image,
    essential = true,
    portMappings = [{ containerPort = 4000, hostPort = 4000 }],
    environment = [{ name = "PORT", value = "4000" }]
  }])
}

resource "aws_ecs_task_definition" "etl" {
  family                   = "${var.project}-etl"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = 512
  memory                   = 1024
  execution_role_arn       = aws_iam_role.task_exec.arn
  container_definitions = jsonencode([{
    name  = "etl",
    image = var.etl_image,
    essential = true,
    portMappings = [{ containerPort = 5000, hostPort = 5000 }],
    environment = [{ name = "PORT", value = "5000" }]
  }])
}

resource "aws_ecs_service" "api" {
  name            = "${var.project}-api"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.api.arn
  desired_count   = 1
  launch_type     = "FARGATE"
  network_configuration {
    subnets         = [aws_subnet.public_a.id, aws_subnet.public_b.id]
    security_groups = [aws_security_group.svc_sg.id]
    assign_public_ip = true
  }
  load_balancer {
    target_group_arn = aws_lb_target_group.api_tg.arn
    container_name   = "api"
    container_port   = 4000
  }
  depends_on = [aws_lb_listener.https]
}

resource "aws_ecs_service" "etl" {
  name            = "${var.project}-etl"
  cluster         = aws_ecs_cluster.this.id
  task_definition = aws_ecs_task_definition.etl.arn
  desired_count   = 1
  launch_type     = "FARGATE"
  network_configuration {
    subnets         = [aws_subnet.public_a.id, aws_subnet.public_b.id]
    security_groups = [aws_security_group.svc_sg.id]
    assign_public_ip = true
  }
  load_balancer {
    target_group_arn = aws_lb_target_group.etl_tg.arn
    container_name   = "etl"
    container_port   = 5000
  }
  depends_on = [aws_lb_listener.https]
}
