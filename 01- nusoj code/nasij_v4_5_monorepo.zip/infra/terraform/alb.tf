
resource "aws_security_group" "alb_sg" {
  name = "${var.project}-alb-sg"
  vpc_id = aws_vpc.this.id
  ingress { from_port = 80, to_port = 80, protocol = "tcp", cidr_blocks = ["0.0.0.0/0"] }
  ingress { from_port = 443, to_port = 443, protocol = "tcp", cidr_blocks = ["0.0.0.0/0"] }
  egress  { from_port = 0, to_port = 0, protocol = "-1", cidr_blocks = ["0.0.0.0/0"] }
}
resource "aws_lb" "this" {
  name = "${var.project}-alb"
  internal = false
  load_balancer_type = "application"
  security_groups = [aws_security_group.alb_sg.id]
  subnets = [aws_subnet.public_a.id, aws_subnet.public_b.id]
}
resource "aws_lb_target_group" "api_tg" {
  name = "${var.project}-api-tg"
  port = 4000
  protocol = "HTTP"
  vpc_id = aws_vpc.this.id
  health_check { path = "/health" }
}
resource "aws_lb_target_group" "etl_tg" {
  name = "${var.project}-etl-tg"
  port = 5000
  protocol = "HTTP"
  vpc_id = aws_vpc.this.id
  health_check { path = "/health" }
}
resource "aws_lb_listener" "http" {
  load_balancer_arn = aws_lb.this.arn
  port = 80
  protocol = "HTTP"
  default_action {
    type = "redirect"
    redirect { port = "443" protocol = "HTTPS" status_code = "HTTP_301" }
  }
}
resource "aws_lb_listener" "https" {
  load_balancer_arn = aws_lb.this.arn
  port = 443
  protocol = "HTTPS"
  ssl_policy = "ELBSecurityPolicy-2016-08"
  certificate_arn = var.acm_certificate_arn
  default_action {
    type = "fixed-response"
    fixed_response { content_type = "text/plain" message_body = "OK" status_code = "200" }
  }
}
