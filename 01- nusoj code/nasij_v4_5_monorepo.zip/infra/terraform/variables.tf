
variable "project" { type = string }
variable "aws_region" { type = string  default = "me-south-1" }
variable "domain_name" { type = string }
variable "hosted_zone_id" { type = string }
variable "acm_certificate_arn" { type = string }
variable "api_image" { type = string }
variable "etl_image" { type = string }
