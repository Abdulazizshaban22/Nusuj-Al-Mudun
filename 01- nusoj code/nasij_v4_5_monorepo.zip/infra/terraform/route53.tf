
resource "aws_lb_listener_rule" "api_forward" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 10
  action { type = "forward" target_group_arn = aws_lb_target_group.api_tg.arn }
  condition { path_pattern { values = ["/ogc/*", "/geojson/*", "/open311/*", "/health"] } }
}

resource "aws_lb_listener_rule" "etl_forward" {
  listener_arn = aws_lb_listener.https.arn
  priority     = 20
  action { type = "forward" target_group_arn = aws_lb_target_group.etl_tg.arn }
  condition { path_pattern { values = ["/alerts/*", "/st/*"] } }
}

resource "aws_route53_record" "app_alias" {
  zone_id = var.hosted_zone_id
  name    = var.domain_name
  type    = "A"
  alias {
    name                   = aws_lb.this.dns_name
    zone_id                = aws_lb.this.zone_id
    evaluate_target_health = true
  }
}
