
from flask import Flask, request, jsonify
from datetime import datetime, timedelta
import numpy as np
import pandas as pd

events = []  # {h3index:str, value:float, ts: ISO8601}

app = Flask(__name__)

@app.get("/health")
def health():
    return {"status":"ok"}

@app.post("/alerts/events/add")
def add_event():
    data = request.get_json(force=True)
    events.append({
        "h3index": data["h3index"],
        "value": float(data["value"]),
        "ts": data.get("ts") or datetime.utcnow().isoformat()
    })
    return {"ok": True, "count": len(events)}

@app.post("/alerts/window/evaluate")
def window_eval():
    data = request.get_json(force=True)
    window = data.get("window","1d")
    now = datetime.utcnow()
    if window.endswith("m"):
        dt = timedelta(minutes=int(window[:-1]))
    elif window.endswith("h"):
        dt = timedelta(hours=int(window[:-1]))
    else:
        dt = timedelta(days=int(window[:-1]) if window[:-1].isdigit() else 1)
    t0 = now - dt
    subset = [e for e in events if datetime.fromisoformat(e["ts"].split("Z")[0]) >= t0]
    agg = {}
    for e in subset:
        agg.setdefault(e["h3index"], []).append(e["value"])
    out = [{"h3index": k, "n": len(v), "sum": float(np.sum(v)), "mean": float(np.mean(v))} for k,v in agg.items()]
    return jsonify({"window": window, "since": t0.isoformat(), "buckets": out})

@app.post("/st/gi_star")
def gi_star():
    # Computes Getis-Ord Gi* for values aggregated on H3 indexes within a time window
    data = request.get_json(force=True)
    window = data.get("window","1d")
    ring = int(data.get("ring",1))
    min_count = int(data.get("min_count",1))
    now = datetime.utcnow()
    if window.endswith("m"):
        dt = timedelta(minutes=int(window[:-1]))
    elif window.endswith("h"):
        dt = timedelta(hours=int(window[:-1]))
    else:
        dt = timedelta(days=int(window[:-1]) if window[:-1].isdigit() else 1)
    t0 = now - dt
    subset = [e for e in events if datetime.fromisoformat(e["ts"].split("Z")[0]) >= t0]
    import h3  # requires h3-py
    by_h3 = {}
    for e in subset:
        by_h3.setdefault(e["h3index"], []).append(e["value"])
    centers = list(by_h3.keys())
    if not centers:
        return jsonify({"since": t0.isoformat(), "ring": ring, "window": window, "results": []})
    y = np.array([np.mean(by_h3[h]) for h in centers])
    # Build spatial weights from k_ring neighbors
    from libpysal.weights import W
    neighbors = {}
    for h in centers:
        nbrs = list(h3.k_ring(h, ring))
        nbrs = [n for n in nbrs if n in by_h3]
        neighbors[h] = nbrs
    w = W(neighbors)
    from esda.getisord import G_Local
    lg = G_Local(y, w, transform='R', star=True)
    result = []
    for idx, h in enumerate(centers):
        n = len(by_h3[h])
        if n < min_count:
            continue
        result.append({
            "h3index": h,
            "n": n,
            "mean": float(np.mean(by_h3[h])),
            "z": float(lg.Zs[idx]),
            "p": float(lg.p_sim[idx])
        })
    return jsonify({"since": t0.isoformat(), "ring": ring, "window": window, "results": result})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
