
import express from 'express';
import bodyParser from 'body-parser';

const app = express();
app.use(bodyParser.json());

type Feature = {
  id: string;
  type: 'Feature';
  geometry: { type: string; coordinates: any };
  properties: Record<string, any>;
  created_at: string;
};
type Open311 = {
  service_request_id: string;
  status: string;
  service_code?: string;
  lat?: number;
  lon?: number;
  requested_datetime: string;
  attributes?: Record<string, any>;
};

const features: Feature[] = [];
const open311: Open311[] = [];

function parseBBox(bboxStr: string) {
  const parts = bboxStr.split(',').map(Number);
  if (![4,6].includes(parts.length) || parts.some(isNaN)) return null;
  return parts;
}
function pointInBBox(coords: [number, number], bbox: number[]) {
  const [x, y] = coords;
  return x >= bbox[0] && y >= bbox[1] && x <= bbox[2] && y <= bbox[3];
}
function inDatetimeRange(tsISO: string, datetimeParam?: string) {
  if (!datetimeParam) return true;
  try {
    if (datetimeParam.includes('/')) {
      const [a,b] = datetimeParam.split('/');
      const t = new Date(tsISO).getTime();
      const t0 = a ? new Date(a).getTime() : -Infinity;
      const t1 = b ? new Date(b).getTime() : Infinity;
      return t >= t0 && t <= t1;
    } else {
      const t = new Date(tsISO).getTime();
      const d = new Date(datetimeParam).getTime();
      return Math.abs(t - d) <= 12*3600*1000;
    }
  } catch {
    return true;
  }
}

// Minimal CQL2-text (key op value) joined by AND
function parseCQL2(filter: string) {
  const tokens = filter.split(/\s+AND\s+/i);
  const clauses = tokens.map(tok => {
    const m = tok.trim().match(/^([A-Za-z0-9_.-]+)\s*(=|!=|>=|<=|>|<)\s*(.+)$/);
    if (!m) return null;
    let [, key, op, rawVal] = m;
    rawVal = rawVal.trim();
    let isString = false;
    if (rawVal.startsWith("'") && rawVal.endsWith("'")) {
      rawVal = rawVal.slice(1,-1);
      isString = true;
    } else if (!isNaN(Number(rawVal))) {
      // numeric
    } else {
      isString = true;
    }
    return { key, op, value: isString ? rawVal : Number(rawVal), isString };
  }).filter(Boolean) as {key:string, op:string, value:any, isString:boolean}[];
  return clauses;
}
function applyCQL2Props(obj: Record<string, any>, clauses: any[]) {
  if (!clauses || clauses.length===0) return true;
  return clauses.every((c:any)=>{
    const v = (obj as any)[c.key] ?? (obj as any)?.properties?.[c.key];
    if (v === undefined) return false;
    const left = c.isString ? String(v) : Number(v);
    const right = c.value;
    switch (c.op) {
      case '=':  return left === right;
      case '!=': return left !== right;
      case '>':  return left > right;
      case '<':  return left < right;
      case '>=': return left >= right;
      case '<=': return left <= right;
    }
    return false;
  });
}
function applySort<T>(list: T[], sortby?: string) {
  if (!sortby) return list;
  const keys = sortby.split(',').map(s => {
    const [k, dir] = s.split(':');
    return { k: k.trim(), d: (dir||'A').toUpperCase()==='D' ? -1 : 1 };
  });
  return list.sort((a:any,b:any)=>{
    for (const {k,d} of keys) {
      const va = a[k] ?? a.properties?.[k];
      const vb = b[k] ?? b.properties?.[k];
      if (va==vb) continue;
      return (va>vb?1:-1) * d;
    }
    return 0;
  });
}

app.get('/ogc/collections', (_req, res) => {
  res.json({
    links: [],
    collections: [
      { id: 'features', itemType: 'feature', title: 'General Features', extent: {} },
      { id: 'open311_requests', itemType: 'record', title: 'Open311 Service Requests', extent: {} }
    ]
  });
});

app.get('/ogc/collections/features/items', (req, res) => {
  const bboxParam = (req.query.bbox as string|undefined);
  const bboxCrs = (req.query['bbox-crs'] as string|undefined);
  const datetimeParam = (req.query.datetime as string|undefined);
  const filter = (req.query.filter as string|undefined);
  const filterLang = (req.query['filter-lang'] as string|undefined);
  const sortby = (req.query.sortby as string|undefined);
  const limit = Math.min(parseInt((req.query.limit as string)||'100'), 1000);

  if (bboxCrs && !/4326|CRS84/i.test(bboxCrs)) {
    return res.status(400).json({ error: "Only CRS84/EPSG:4326 supported for bbox-crs in this demo."});
  }

  let items = features.filter(f => {
    let ok = true;
    if (bboxParam) {
      const bbox = parseBBox(bboxParam);
      if (bbox && f.geometry?.type === 'Point') {
        ok = ok && pointInBBox(f.geometry.coordinates as [number,number], bbox);
      }
    }
    ok = ok && inDatetimeRange(f.created_at, datetimeParam);
    if (filter && (!filterLang || /cql2-text/i.test(filterLang))) {
      const clauses = parseCQL2(filter);
      ok = ok && applyCQL2Props(f as any, clauses);
    }
    return ok;
  });

  items = applySort(items, sortby).slice(0, limit);
  res.json({ type: 'FeatureCollection', features: items });
});

app.get('/ogc/collections/open311_requests/items', (req, res) => {
  const datetimeParam = (req.query.datetime as string|undefined);
  const filter = (req.query.filter as string|undefined);
  const filterLang = (req.query['filter-lang'] as string|undefined);
  const sortby = (req.query.sortby as string|undefined);
  const limit = Math.min(parseInt((req.query.limit as string)||'100'), 1000);

  let items = open311.filter(r => {
    let ok = true;
    ok = ok && inDatetimeRange(r.requested_datetime, datetimeParam);
    if (filter && (!filterLang || /cql2-text/i.test(filterLang))) {
      const clauses = parseCQL2(filter);
      ok = ok && applyCQL2Props(r as any, clauses);
    }
    return ok;
  });

  items = applySort(items as any[], sortby).slice(0, limit);
  res.json({ type: 'FeatureCollection', features: items.map(r => ({
    type: 'Feature',
    geometry: (r.lat!=null && r.lon!=null) ? { type: 'Point', coordinates: [r.lon, r.lat] } : null,
    properties: r
  }))});
});

app.post('/geojson/ingest', (req, res) => {
  const fc = req.body;
  if (!fc || fc.type!=='FeatureCollection' || !Array.isArray(fc.features)) {
    return res.status(400).json({ error: 'Expected FeatureCollection' });
  }
  const now = new Date().toISOString();
  for (const f of fc.features) {
    const obj: Feature = {
      id: (f.id || Math.random().toString(36).slice(2)),
      type: 'Feature',
      geometry: f.geometry,
      properties: f.properties || {},
      created_at: now
    };
    features.push(obj);
  }
  res.json({ ok: true, inserted: fc.features.length });
});

app.post('/open311/requests', (req, res) => {
  const r = req.body;
  const obj: Open311 = {
    service_request_id: r.service_request_id || Math.random().toString(36).slice(2),
    status: r.status || 'open',
    service_code: r.service_code,
    lat: r.lat, lon: r.lon,
    requested_datetime: r.requested_datetime || new Date().toISOString(),
    attributes: r.attributes || {}
  };
  open311.push(obj);
  res.json(obj);
});

app.get('/health', (_req,res)=>res.json({status:'ok', ts: new Date().toISOString()}));

const PORT = parseInt(process.env.PORT || '4000', 10);
app.listen(PORT, ()=> console.log(`API listening on :${PORT}`));
