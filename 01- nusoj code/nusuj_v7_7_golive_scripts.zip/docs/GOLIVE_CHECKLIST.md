
# Go‑Live Checklist — NUSUJ

## Identity & Security
- [ ] Keycloak realm imported (nusuj) + clients (admin/citizen) + roles.
- [ ] Redirect URIs/Web Origins set for admin/citizen.
- [ ] (After approval) Nafath channel enabled and tested.
- [ ] WAF (CF + ALB) rules verified (rate limits, managed sets).

## AWS Infra
- [ ] Route53 hosted zone points to your domain.
- [ ] ACM validation succeeded (ALB region + us-east-1 for CloudFront).
- [ ] CloudFront + OAC serves S3 (private) for cdn.nusuj.sa.
- [ ] ALB listener + target groups healthy.
- [ ] ECS services running with desired count.

## Data & Apps
- [ ] KPIs seeded from GASTAT/Balady (or APIs wired).
- [ ] Story Maps load (YAML) and layers render (MapLibre/OGC/CQL2).
- [ ] AI‑Twin nowcast endpoint returns JSON 200.
- [ ] Citizen PWA installable and Web Push allowed.

## Observability
- [ ] CloudWatch logs for all services.
- [ ] Grafana dashboards imported and show traffic/errors/latency.
- [ ] Alerting channels configured (Email/SNS).
