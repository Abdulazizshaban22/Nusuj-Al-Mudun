
# Rollback Plan

1) **ECS Services**: use `aws ecs update-service --desired-count` to scale out the last known-good task definition, or `--force-new-deployment` to roll back to a previous revision.
2) **ALB Listeners**: switch default action to the stable target group.
3) **CloudFront**: create an invalidation for `/` and `/static/*` if needed.
4) **Terraform**: use `terraform state` to inspect resources, and `terraform apply` with the previous `tfstate` backup to restore.
5) **Keycloak**: re-import the last backed-up realm JSON.
