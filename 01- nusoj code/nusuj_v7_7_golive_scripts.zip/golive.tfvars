
project        = "nusuj"
region         = "me-central-1"
hosted_zone_id = "ZXXXXXXXXXXXX"   # Route53 Hosted Zone ID
domain_admin   = "admin.nusuj.sa"
domain_citizen = "citizen.nusuj.sa"
domain_cdn     = "cdn.nusuj.sa"

vpc_id          = "vpc-xxxxxxxx"
public_subnets  = ["subnet-aaaaaa", "subnet-bbbbbb"]
private_subnets = ["subnet-cccccc", "subnet-dddddd"]

# ECR or Docker Hub images
api_image      = "ACCOUNT.dkr.ecr.me-central-1.amazonaws.com/nusuj-api:latest"
admin_image    = "ACCOUNT.dkr.ecr.me-central-1.amazonaws.com/nusuj-admin:latest"
citizen_image  = "ACCOUNT.dkr.ecr.me-central-1.amazonaws.com/nusuj-citizen:latest"
ai_twin_image  = "ACCOUNT.dkr.ecr.me-central-1.amazonaws.com/nusuj-ai-twin:latest"

# Optional env maps can be passed via -var-file with HCL maps, or set later
env_api     = {}
env_admin   = {}
env_citizen = {}
env_ai_twin = {}
