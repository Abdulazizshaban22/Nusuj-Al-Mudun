
#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TF_DIR="$ROOT_DIR/terraform"
TFVARS="${1:-$ROOT_DIR/golive.tfvars}"

echo ">> Using tfvars: $TFVARS"
test -f "$TFVARS" || { echo "Missing tfvars file: $TFVARS"; exit 1; }

pushd "$TF_DIR" >/dev/null

echo ">> terraform init"
terraform init -input=false

echo ">> terraform apply"
terraform apply -input=false -auto-approve -var-file="$TFVARS"

echo ">> reading outputs"
terraform output -json > "$ROOT_DIR/outputs.json"
cat "$ROOT_DIR/outputs.json"

popd >/dev/null

echo ">> waiting for ACM issuance (CloudFront & ALB)"
"$ROOT_DIR/scripts/check-acm.sh" "$TFVARS"

echo ">> (optional) force new deployment for ECS services"
"$ROOT_DIR/scripts/update-ecs.sh" || true

echo ">> Go-Live completed. Next:"
echo "  1) Import Keycloak realm and set Redirect URIs."
echo "  2) Test https://admin.nusuj.sa , https://citizen.nusuj.sa , https://cdn.nusuj.sa"
echo "  3) Run data/etl scripts to populate KPIs."
