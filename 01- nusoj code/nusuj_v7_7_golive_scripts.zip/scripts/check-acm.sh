
#!/usr/bin/env bash
set -euo pipefail

TFVARS="${1:-golive.tfvars}"
REGION="$(awk -F'=' '/region/{gsub(/[ "]/,"",$2); print $2}' "$TFVARS" | tail -n1)"
REGION="${REGION:-me-central-1}"

echo ">> Checking ACM certificates status..."
echo "   - Regional (for ALB) in $REGION"
aws acm list-certificates --region "$REGION" --output table | sed -n '1,80p' || true

echo "   - Global (for CloudFront) in us-east-1"
aws acm list-certificates --region us-east-1 --output table | sed -n '1,80p' || true

echo ">> Ensure validation CNAMEs are present in Route53 (created by Terraform)."
echo ">> This script only lists; issuance can take a few minutes after DNS propagates."
