
#!/usr/bin/env bash
set -euo pipefail

KEYCLOAK_URL="${KEYCLOAK_URL:-https://id.nusuj.sa}"
REALM_FILE="${REALM_FILE:-keycloak/realm-nusuj.json}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASS="${ADMIN_PASS:-admin}"

echo ">> Importing realm to Keycloak at $KEYCLOAK_URL"
echo ">> Requires kcadm.sh available in PATH with version >= 22.x"
kcadm.sh config credentials --server "$KEYCLOAK_URL" --realm master --user "$ADMIN_USER" --password "$ADMIN_PASS"
kcadm.sh create partialImport -r master -s ifResourceExists=OVERWRITE -o -f "$REALM_FILE" || true

echo ">> Set Valid Redirect URIs / Web Origins inside Admin Console for:"
echo "   - https://admin.nusuj.sa/*"
echo "   - https://citizen.nusuj.sa/*"
