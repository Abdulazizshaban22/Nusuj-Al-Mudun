
#!/usr/bin/env bash
set -euo pipefail
python3 data/etl/gastat_to_kpi.py data/samples/gastat_population.csv || true
python3 data/etl/balady_permits_to_kpi.py data/samples/balady_permits.csv || true
echo ">> KPIs JSON written next to scripts."
