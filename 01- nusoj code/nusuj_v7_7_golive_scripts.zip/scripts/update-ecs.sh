
#!/usr/bin/env bash
set -euo pipefail
CLUSTER="${CLUSTER:-nusuj-cluster}"

echo ">> Forcing new deployment for ECS services on cluster: $CLUSTER"
for SVC in nusuj-api nusuj-admin nusuj-citizen nusuj-ai-twin; do
  if aws ecs describe-services --cluster "$CLUSTER" --services "$SVC" --query 'services[0].serviceName' --output text 2>/dev/null | grep -q "$SVC"; then
    echo " - Update $SVC"
    aws ecs update-service --cluster "$CLUSTER" --service "$SVC" --force-new-deployment >/dev/null || true
  else
    echo " - Skip $SVC (not found)"
  fi
done
