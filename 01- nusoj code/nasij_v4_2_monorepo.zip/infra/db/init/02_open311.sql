-- Open311-like tables (minimal draft for GeoReport v2)
CREATE TABLE IF NOT EXISTS urban.open311_services (
  service_code TEXT PRIMARY KEY,
  service_name TEXT NOT NULL,
  description TEXT,
  metadata BOOLEAN DEFAULT TRUE,
  type TEXT DEFAULT 'realtime',
  keywords TEXT[] DEFAULT ARRAY[]::TEXT[],
  group_name TEXT
);

CREATE TABLE IF NOT EXISTS urban.open311_requests (
  service_request_id BIGSERIAL PRIMARY KEY,
  service_code TEXT REFERENCES urban.open311_services(service_code),
  description TEXT,
  status TEXT DEFAULT 'open',
  requested_datetime TIMESTAMPTZ DEFAULT now(),
  updated_datetime TIMESTAMPTZ DEFAULT now(),
  address_string TEXT,
  lat DOUBLE PRECISION,
  lng DOUBLE PRECISION,
  geom geometry(Point,4326),
  attributes JSONB DEFAULT '{}'::jsonb
);

CREATE INDEX IF NOT EXISTS open311_geom_gix ON urban.open311_requests USING gist(geom);