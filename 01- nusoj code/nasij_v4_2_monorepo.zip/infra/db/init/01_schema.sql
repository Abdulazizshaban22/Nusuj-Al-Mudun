CREATE SCHEMA IF NOT EXISTS urban;

CREATE TABLE IF NOT EXISTS urban.h3_cells (
  id BIGSERIAL PRIMARY KEY,
  h3index TEXT UNIQUE,
  centroid geometry(POINT, 4326),
  props JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS urban.embeddings (
  id BIGSERIAL PRIMARY KEY,
  entity_type TEXT,
  entity_id BIGINT,
  vector vector(384)
);