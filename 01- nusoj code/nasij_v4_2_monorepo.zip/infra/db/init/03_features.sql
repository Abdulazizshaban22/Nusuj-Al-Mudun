CREATE TABLE IF NOT EXISTS urban.features (
  id BIGSERIAL PRIMARY KEY,
  source TEXT,
  props JSONB,
  geom geometry(Geometry,4326),
  created_at TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS features_geom_gix ON urban.features USING gist(geom);