from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import numpy as np, os, json

from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

from h3 import h3
import psycopg
from esda import G_Local
import libpysal

app = FastAPI(title="NASIJ ETL", version="4.2.0")

REQS = Counter("etl_requests_total", "Total requests", ["endpoint"])
LAT  = Histogram("etl_request_seconds", "Latency seconds", ["endpoint"])

DB_URL = os.environ.get("DATABASE_URL")

@app.get("/health")
def health():
    REQS.labels(endpoint="/health").inc()
    return {"status":"ok","service":"etl","version":"4.2.0"}

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

# ----- Fabric Index -----
class FabricInput(BaseModel):
    morphology: float
    environment: float
    accessibility: float
    weights: tuple[float, float, float] = (0.4, 0.3, 0.3)

@app.post("/fabric/index")
def fabric_index(inp: FabricInput):
    REQS.labels(endpoint="/fabric/index").inc()
    w = np.array(inp.weights, dtype=float)
    x = np.array([inp.morphology, inp.environment, inp.accessibility], dtype=float)
    w = w / w.sum()
    return {"fabric_index": float(np.clip((w*x).sum(),0,1))*100.0, "weights": w.tolist()}

@app.get("/fabric/demo")
def fabric_demo():
    REQS.labels(endpoint="/fabric/demo").inc()
    x = np.array([0.62, 0.48, 0.71])
    w = np.array([0.4, 0.3, 0.3])
    return {"fabric_index": float(np.clip((w*x).sum(),0,1))*100.0, "components":{"morphology":0.62,"environment":0.48,"accessibility":0.71}}

# ----- H3 / Hotspots -----
class H3IndexIn(BaseModel):
    lat: float
    lng: float
    res: int

@app.post("/h3/index")
def h3_index(inp: H3IndexIn):
    REQS.labels(endpoint="/h3/index").inc()
    if not (0 <= inp.res <= 15):
        raise HTTPException(400, "res must be 0..15")
    return {"h3index": h3.geo_to_h3(inp.lat, inp.lng, inp.res)}

class H3HotspotItem(BaseModel):
    h3index: str
    value: float

class H3HotspotIn(BaseModel):
    items: List[H3HotspotItem]
    ring: int = 1

@app.post("/h3/hotspots")
def h3_hotspots(inp: H3HotspotIn):
    REQS.labels(endpoint="/h3/hotspots").inc()
    cells = [it.h3index for it in inp.items]
    values = np.array([it.value for it in inp.items])
    if len(cells) != len(set(cells)):
        raise HTTPException(400, "duplicate h3index")
    neighbors = {}
    cellset = set(cells)
    for c in cells:
        neigh = set(h3.k_ring(c, inp.ring)) & cellset
        neighbors[c] = list(neigh)
    w = libpysal.weights.W(neighbors, silence_warnings=True); w.transform='R'
    g = G_Local(values, w, star=True)
    out = [{"h3index": c, "z": float(z), "p": float(p)} for c, z, p in zip(cells, g.Zs, g.p_sim)]
    out.sort(key=lambda r: abs(r["z"]), reverse=True)
    return {"n": len(out), "results": out}

# ----- GeoJSON ingest -----
class Feature(BaseModel):
    type: str
    geometry: Dict[str, Any]
    properties: Optional[Dict[str, Any]] = None

class FeatureCollection(BaseModel):
    type: str
    features: List[Feature]
    source: Optional[str] = "upload"

@app.post("/geojson/ingest")
def geojson_ingest(fc: FeatureCollection):
    REQS.labels(endpoint="/geojson/ingest").inc()
    if fc.type != "FeatureCollection":
        raise HTTPException(400, "type must be FeatureCollection")
    if not DB_URL:
        raise HTTPException(500, "DATABASE_URL not set")
    n=0
    with psycopg.connect(DB_URL) as con:
        with con.cursor() as cur:
            for f in fc.features:
                geom = json.dumps(f.geometry)
                props = json.dumps(f.properties or {})
                cur.execute(
                    "INSERT INTO urban.features (source, props, geom) VALUES (%s, %s, ST_SetSRID(ST_GeomFromGeoJSON(%s),4326))",
                    (fc.source or "upload", props, geom)
                )
                n+=1
        con.commit()
    return {"inserted": n}