import 'reflect-metadata';
import { createServer } from 'http';
import { Pool } from 'pg';
import client, { Counter, Histogram, Registry } from 'prom-client';
import { verifyToken, hasRole } from './auth';

const PORT = process.env.PORT ? parseInt(process.env.PORT) : 4000;
const DB_URL = process.env.DATABASE_URL || "";
const pool = new Pool({ connectionString: DB_URL });

const register = new Registry();
client.collectDefaultMetrics({ register });
const requests = new Counter({ name: 'api_requests_total', help: 'requests', labelNames: ['route','method','code'] });
const latency  = new Histogram({ name: 'api_request_seconds', help: 'latency', labelNames: ['route'] });
register.registerMetric(requests);
register.registerMetric(latency);

function send(res:any, code:number, obj:any){
  res.writeHead(code, {'Content-Type':'application/json'});
  res.end(JSON.stringify(obj));
}

async function parseBody(req:any): Promise<any> {
  return new Promise((resolve) => {
    let data = ''; req.on('data',(c:any)=>data+=c); req.on('end',()=>{
      try{ resolve(JSON.parse(data||'{}')); } catch{ resolve({}); }
    });
  });
}

const server = createServer(async (req, res) => {
  const url = req.url || '/';
  const method = req.method || 'GET';
  const endTimer = latency.labels(url).startTimer();
  try {
    if (url === '/health') { requests.labels('/health',method,'200').inc(); return send(res,200,{status:'ok', service:'api', version:'4.2.0'}); }
    if (url === '/metrics') { const metrics = await register.metrics(); res.writeHead(200, {'Content-Type': register.contentType}); res.end(metrics); return; }

    // --- Open311: services ---
    if (url === '/open311/services' && method === 'GET') {
      const rs = await pool.query('SELECT service_code, service_name, description, metadata, type, keywords, group_name FROM urban.open311_services ORDER BY service_code');
      requests.labels('/open311/services',method,'200').inc();
      return send(res,200, rs.rows);
    }

    // --- Open311: requests ---
    if (url.startsWith('/open311/requests') && method === 'GET') {
      const rs = await pool.query('SELECT service_request_id, service_code, status, requested_datetime, updated_datetime, address_string, lat, lng, attributes FROM urban.open311_requests ORDER BY service_request_id DESC LIMIT 200');
      requests.labels('/open311/requests',method,'200').inc();
      return send(res,200, rs.rows);
    }
    if (url === '/open311/requests' && method === 'POST') {
      // optional RBAC: municipality or citizen allowed
      const auth = req.headers['authorization'];
      if (process.env.KEYCLOAK_JWKS_URL) {
        if (!auth || !auth.startsWith('Bearer ')) { requests.labels('/open311/requests',method,'401').inc(); return send(res,401,{error:'missing_token'}); }
        try {
          const payload = await verifyToken(auth.split(' ')[1]);
          if (!(hasRole(payload,'municipality') || hasRole(payload,'citizen'))) { requests.labels('/open311/requests',method,'403').inc(); return send(res,403,{error:'forbidden'}); }
        } catch(e:any) {
          requests.labels('/open311/requests',method,'401').inc(); return send(res,401,{error:'invalid_token', detail: e?.message});
        }
      }
      const body = await parseBody(req);
      const { service_code, description, lat, lng, address_string, attributes } = body || {};
      if (!service_code) { requests.labels('/open311/requests',method,'400').inc(); return send(res,400,{error:'service_code required'}); }
      const geomSql = (lat!=null && lng!=null) ? "ST_SetSRID(ST_Point($5,$4),4326)" : "NULL";
      const rs = await pool.query(
        `INSERT INTO urban.open311_requests (service_code, description, address_string, lat, lng, geom, attributes)
         VALUES ($1,$2,$3,$4,$5, ${geomSql}, COALESCE($6,'{}'::jsonb)) RETURNING service_request_id, status, requested_datetime`,
        [service_code, description||null, address_string||null, lat||null, lng||null, (attributes ? JSON.stringify(attributes) : null)]
      );
      requests.labels('/open311/requests',method,'201').inc();
      return send(res,201, rs.rows[0]);
    }

    // --- Secure ping (municipality role) ---
    if (url.startsWith('/secure/ping')) {
      const auth = req.headers['authorization'];
      if (!auth || !auth.startsWith('Bearer ')) { requests.labels('/secure/ping',method,'401').inc(); return send(res,401,{error:'Missing bearer token'}); }
      try {
        const payload = await verifyToken(auth.split(' ')[1]);
        if (!hasRole(payload, 'municipality')) { requests.labels('/secure/ping',method,'403').inc(); return send(res,403,{error:'insufficient_role'}); }
        requests.labels('/secure/ping',method,'200').inc();
        return send(res,200,{ok:true});
      } catch(e:any){
        requests.labels('/secure/ping',method,'401').inc();
        return send(res,401,{error:'invalid_token', detail: e?.message});
      }
    }

    // default
    requests.labels('root',method,'200').inc();
    return send(res,200,{message:'NASIJ API v4.2'});
  } catch (e:any) {
    requests.labels(url,method,'500').inc();
    return send(res,500,{error:'server_error', detail:e?.message});
  } finally {
    endTimer();
  }
});

server.listen(PORT, () => console.log('API on', PORT));