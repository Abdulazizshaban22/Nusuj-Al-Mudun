'use client';
import { useState, useEffect } from 'react';

export default function Citizen(){
  const [list, setList] = useState([]);
  const [form, setForm] = useState({service_code:'TRASH', description:'', lat:'', lng:'', address_string:'', attributes:{} });

  useEffect(()=>{ load(); },[]);
  async function load(){
    const res = await fetch(process.env.API_BASE_URL + '/open311/requests');
    const out = await res.json();
    setList(out);
  }
  async function submit(){
    const res = await fetch(process.env.API_BASE_URL + '/open311/requests', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({
        service_code: form.service_code,
        description: form.description,
        lat: form.lat ? parseFloat(form.lat): null,
        lng: form.lng ? parseFloat(form.lng): null,
        address_string: form.address_string,
        attributes: form.attributes
      })
    });
    await load();
  }
  return (
    <main style={{padding:24,fontFamily:"ui-sans-serif"}}>
      <h2>NASIJ Citizen — بلاغات (Open311)</h2>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
        <div>
          <h3>إضافة بلاغ</h3>
          <label>Service Code</label><br/>
          <input value={form.service_code} onChange={e=>setForm({...form,service_code:e.target.value})} /><br/>
          <label>الوصف</label><br/>
          <textarea value={form.description} onChange={e=>setForm({...form,description:e.target.value})} /><br/>
          <label>Lat</label><br/>
          <input value={form.lat} onChange={e=>setForm({...form,lat:e.target.value})} /><br/>
          <label>Lng</label><br/>
          <input value={form.lng} onChange={e=>setForm({...form,lng:e.target.value})} /><br/>
          <label>العنوان</label><br/>
          <input value={form.address_string} onChange={e=>setForm({...form,address_string:e.target.value})} /><br/>
          <button onClick={submit} style={{marginTop:8}}>إرسال</button>
        </div>
        <div>
          <h3>آخر البلاغات</h3>
          <ul>
            {list.map((r)=> <li key={r.service_request_id}>
              #{r.service_request_id} — {r.service_code} — {r.status} — {r.address_string || ''}
            </li>)}
          </ul>
        </div>
      </div>
    </main>
  );
}