export default async function Home(){
  const api = await fetch(process.env.API_BASE_URL + "/health", {cache:"no-store"}).then(r=>r.json()).catch(()=>({status:"off"}));
  const etl = await fetch(process.env.ETL_BASE_URL + "/health", {cache:"no-store"}).then(r=>r.json()).catch(()=>({status:"off"}));
  return (
    <main style={{padding:24,fontFamily:"ui-sans-serif"}}>
      <h1>NASIJ v4.2 — لوحة البدء</h1>
      <p>نسخة تطوير مع Studio + Citizen + Open311.</p>
      <ul>
        <li>API: {api?.status}</li>
        <li>ETL: {etl?.status}</li>
      </ul>
      <div style={{marginTop:16,display:"flex",gap:16}}>
        <a href="/studio" style={{textDecoration:"underline"}}>فتح Studio</a>
        <a href="/citizen" style={{textDecoration:"underline"}}>فتح Citizen</a>
      </div>
    </main>
  );
}