# NASIJ v4.2 — Studio + Citizen + Open311
منصة النسيج الحضري الوطنية — هذه النسخة تضيف:
- **NASIJ Studio**: رفع GeoJSON وبدء التحليلات (ingest → H3/Gi*).
- **NASIJ Citizen**: نموذج بلاغات مواطنين متوافق مع **Open311** (GeoReport v2).
- **Open311 API**: `/open311/services` + `/open311/requests` (POST/GET).
- **ETL GeoJSON**: `/geojson/ingest` لتخزين FeatureCollection في PostGIS.
- **المراقبة**: Prometheus + Grafana (لوحة جاهزة).
- **RBAC جاهز**: ربط JWKS من Keycloak (دور municipality/engineer/citizen).

> المعايير المعتمدة: **Open311 GeoReport v2**, **RFC 7946 GeoJSON**, **OGC API-Features (قراءة/Features)**.

## التشغيل السريع
```bash
cp .env.example .env
docker compose up -d --build
# Web:       http://localhost:3000
# API:       http://localhost:4000
# ETL:       http://localhost:5000/docs
# Prometheus http://localhost:9090
# Grafana    http://localhost:3001  (admin/admin)
```

## خرائط الطريق
- v4.3: توأم حضري حي للحي/البلدية + Streaming Alerts + Open311 → Open Data (OGC).
- v4.4: Terraform/ECS + Secrets Manager + PDPL Evidence Pack.