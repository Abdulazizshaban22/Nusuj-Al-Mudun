from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import numpy as np, os, json, yaml, re
from dateutil import parser as dtp
from datetime import datetime, timedelta, timezone

from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

from h3 import h3
import psycopg
from esda import G_Local
import libpysal

app = FastAPI(title="NASIJ ETL", version="4.4.0")

REQS = Counter("etl_requests_total", "Total requests", ["endpoint"])
LAT  = Histogram("etl_request_seconds", "Latency seconds", ["endpoint"])

DB_URL = os.environ.get("DATABASE_URL")

@app.get("/health")
def health():
    REQS.labels(endpoint="/health").inc()
    return {"status":"ok","service":"etl","version":"4.4.0"}

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

# ----- H3 / Hotspots -----
class H3IndexIn(BaseModel):
    lat: float; lng: float; res: int
@app.post("/h3/index")
def h3_index(inp: H3IndexIn):
    REQS.labels(endpoint="/h3/index").inc()
    if not (0 <= inp.res <= 15): raise HTTPException(400, "res must be 0..15")
    return {"h3index": h3.geo_to_h3(inp.lat, inp.lng, inp.res)}

class H3HotspotItem(BaseModel):
    h3index: str; value: float
class H3HotspotIn(BaseModel):
    items: List[H3HotspotItem]; ring: int = 1
@app.post("/h3/hotspots")
def h3_hotspots(inp: H3HotspotIn):
    REQS.labels(endpoint="/h3/hotspots").inc()
    cells = [it.h3index for it in inp.items]; values = np.array([it.value for it in inp.items])
    if len(cells) != len(set(cells)): raise HTTPException(400, "duplicate h3index")
    neighbors = {}; cellset = set(cells)
    for c in cells:
        neigh = set(h3.k_ring(c, inp.ring)) & cellset
        neighbors[c] = list(neigh)
    w = libpysal.weights.W(neighbors, silence_warnings=True); w.transform='R'
    g = G_Local(values, w, star=True)
    out = [{"h3index": c, "z": float(z), "p": float(p)} for c, z, p in zip(cells, g.Zs, g.p_sim)]
    out.sort(key=lambda r: abs(r["z"]), reverse=True)
    return {"n": len(out), "results": out}

# ----- GeoJSON ingest -----
class Feature(BaseModel):
    type: str; geometry: Dict[str, Any]; properties: Optional[Dict[str, Any]] = None
class FeatureCollection(BaseModel):
    type: str; features: List[Feature]; source: Optional[str] = "upload"
@app.post("/geojson/ingest")
def geojson_ingest(fc: FeatureCollection):
    REQS.labels(endpoint="/geojson/ingest").inc()
    if fc.type != "FeatureCollection": raise HTTPException(400, "type must be FeatureCollection")
    if not DB_URL: raise HTTPException(500, "DATABASE_URL not set")
    n=0
    with psycopg.connect(DB_URL) as con:
        with con.cursor() as cur:
            for f in fc.features:
                geom = json.dumps(f.geometry); props = json.dumps(f.properties or {})
                cur.execute("INSERT INTO urban.features (source, props, geom) VALUES (%s,%s,ST_SetSRID(ST_GeomFromGeoJSON(%s),4326))",
                            (fc.source or "upload", props, geom)); n+=1
        con.commit()
    return {"inserted": n}

# ----- Temporal Alerts (sliding window) -----
class Rule(BaseModel):
    name: str
    metric: str   # e.g., 'value' or 'gi_z'
    op: str       # '>' or '<'
    threshold: float
_rules: List[Dict[str, Any]] = []

@app.post("/alerts/rules")
def add_rule(rule: Rule):
    REQS.labels(endpoint="/alerts/rules").inc()
    if rule.op not in ('>','<'): raise HTTPException(400, "op must be '>' or '<'")
    _rules.append(rule.dict())
    return {"rules": _rules}

class Event(BaseModel):
    h3index: str
    value: float
    metric: str = "value"
    ts: Optional[str] = None  # ISO time
_events: List[Dict[str, Any]] = []

@app.post("/alerts/events/add")
def add_event(ev: Event):
    REQS.labels(endpoint="/alerts/events/add").inc()
    t = dtp.parse(ev.ts).astimezone(timezone.utc) if ev.ts else datetime.now(timezone.utc)
    _events.append({"h3index": ev.h3index, "metric": ev.metric, "value": ev.value, "ts": t})
    return {"n": len(_events)}

def parse_window(s: str) -> timedelta:
    m = re.match(r"^(\d+)([smhd])$", s)
    if not m: raise HTTPException(400, "window must be like 15m / 2h / 1d")
    n = int(m.group(1)); u = m.group(2)
    if u=='s': return timedelta(seconds=n)
    if u=='m': return timedelta(minutes=n)
    if u=='h': return timedelta(hours=n)
    if u=='d': return timedelta(days=n)
    raise HTTPException(400, "invalid window unit")

class WindowEvalIn(BaseModel):
    window: str = "15m"
    metric: str = "value"

@app.post("/alerts/window/evaluate")
def window_evaluate(inp: WindowEvalIn):
    REQS.labels(endpoint="/alerts/window/evaluate").inc()
    now = datetime.now(timezone.utc)
    delta = parse_window(inp.window)
    start = now - delta
    # filter events
    evs = [e for e in _events if e["metric"]==inp.metric and e["ts"]>=start]
    # aggregate per h3
    agg: Dict[str, Dict[str, float]] = {}
    for e in evs:
        a = agg.setdefault(e["h3index"], {"count":0,"sum":0.0,"max":float("-inf")})
        a["count"] += 1; a["sum"] += e["value"]; a["max"] = max(a["max"], e["value"])
    # apply rules
    alerts = []
    for r in _rules:
        if r["metric"] != inp.metric: continue
        for h3i, a in agg.items():
            val = a["max"]
            ok = (val > r["threshold"]) if r["op"] == ">" else (val < r["threshold"])
            if ok: alerts.append({"rule": r["name"], "h3index": h3i, "value": val})
    return {"window": inp.window, "metric": inp.metric, "n_events": len(evs), "aggregates": agg, "alerts": alerts}