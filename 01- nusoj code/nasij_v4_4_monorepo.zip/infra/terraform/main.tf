terraform {
  required_version = ">= 1.5.0"
  required_providers { aws = { source = "hashicorp/aws", version = ">= 5.0" } }
}
provider "aws" { region = var.region }

resource "aws_ecs_cluster" "nasij" { name = "nasij-cluster" }

# ملاحظة: استكمل شبكات VPC/Subnets و ALB و ECS Services و Task Definitions.
# يفضّل تخزين الأسرار في Secrets Manager وتمريرها للمهام كمتغيرات بيئية.