# Terraform — نشر سيادي على AWS (هيكل أولي)
- **ECS (Fargate)** لتشغيل `api` و`etl` + **ALB** لمسارات HTTP/HTTPS.
- **ACM** لشهادات TLS، **Route53** للنطاقات، **Secrets Manager** للأسرار.
- **CloudWatch Logs** + التكامل مع Prometheus/Grafana.

> اتبع ممارسات AWS الرسمية لنشر ECS + ALB + Secrets Manager.