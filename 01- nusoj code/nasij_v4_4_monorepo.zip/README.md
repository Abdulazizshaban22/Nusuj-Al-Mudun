# NASIJ v4.4 — OGC Filters + Temporal Alerts + Terraform/PDPL
- **OGC API-Features (قراءة + فلاتر)**: `bbox` و`datetime` لمجموعتي `features` و`open311_requests` (GeoJSON).
- **Temporal Alerts**: نافذة منزلقة مع قواعد عتبات.
- **Terraform (هيكل)**: ECS + ALB + Secrets Manager.
- **PDPL Evidence Pack**: سجلات ونماذج امتثال.

تشغيل محلي:
```bash
cp .env.example .env
docker compose up -d --build
# Web: http://localhost:3000 | API: http://localhost:4000 | ETL: http://localhost:5000/docs
# Prometheus: 9090 | Grafana: 3001 (admin/admin)
```