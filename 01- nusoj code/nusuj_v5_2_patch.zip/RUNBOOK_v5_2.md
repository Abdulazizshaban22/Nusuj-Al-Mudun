
# NUSUJ v5.2 — KPIs + Story Maps Advanced (Patch)

## ماذا يضيف
- **/kpi/definitions** محدث + **/kpi/compute** (حسابات من قاعدة البيانات أو من params).
- واجهة **web-admin**: صفحة جديدة **/kpi/compute** لحساب المؤشرات مباشرة.
- تحسين **Story Maps** (التنقّل بين المقاطع).
- تحديثات API: دمج PostGIS (v5.1) + STAC + OGC items + Open311.

## التطبيق فوق v5.1
انسخ ملفات هذا الـpatch فوق المستودع (استبدال الملفات في `services/api` و`services/web-admin` و`story/` و`kpi/`).

## اختبارات سريعة
```bash
# تعريفات المؤشرات
curl http://localhost:4000/kpi/definitions

# حساب التغطية الخضراء بمعامل NDVI متوسط ومساحة حضرية
curl -X POST http://localhost:4000/kpi/compute -H "content-type: application/json" -d '{"kpi_id":"green_cover_ratio","params":{"ndvi_mean":0.35,"area_urban_km2":12}}'

# حساب معدل التشوه البصري لكل كم² (يلزم area_km2)
curl -X POST http://localhost:4000/kpi/compute -H "content-type: application/json" -d '{"kpi_id":"visual_pollution_rate","params":{"area_km2":5}}'
```
