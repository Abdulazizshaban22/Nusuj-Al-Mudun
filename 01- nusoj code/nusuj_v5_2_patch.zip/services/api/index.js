
import express from 'express';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';
import url from 'url';
import pkg from 'pg';

const { Pool } = pkg;
const pool = new Pool({
  host: process.env.PGHOST||'db',
  port: +(process.env.PGPORT||5432),
  user: process.env.PGUSER||'nusuj',
  password: process.env.PGPASSWORD||'nusuj',
  database: process.env.PGDATABASE||'nusuj',
  max: 10
});

const app = express();
app.use(bodyParser.json());

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));

function parseBBox(s){
  if(!s) return null;
  const p = s.split(',').map(Number);
  if(p.length!==4 || p.some(isNaN)) return null;
  return p; // [minx,miny,maxx,maxy]
}
function parseDatetimeRange(d){
  if(!d) return null;
  if(String(d).includes('/')){
    const [a,b]=String(d).split('/'); return {from: a||null, to: b||null};
  }
  return {at: d};
}
function safeFilterToSQL(filter, table){
  if(!filter) return {where:'TRUE', params:[]};
  const parts = String(filter).split(/\s+AND\s+/i);
  const clauses = []; const params = [];
  for(const p of parts){
    const m = p.trim().match(/^([A-Za-z0-9_.-]+)\s*(=|!=|>=|<=|>|<)\s*(.+)$/);
    if(!m) continue;
    let [,key,op,raw]=m;
    let col = null;
    if(table==='features'){
      if(key==='class'){ col = "(properties->>'class')"; }
      else if(key==='score'){ col = "(properties->>'score')::double precision"; }
    }else if(table==='open311_requests'){
      if(key==='status'){ col = 'status'; }
      else if(key==='service_code'){ col = 'service_code'; }
    }
    if(!col) continue;
    let val = raw;
    if(val.startsWith("'") && val.endsWith("'")) val = val.slice(1,-1);
    clauses.push(`${col} ${op==='!='?'<>':op} $${params.length+1}`);
    params.push(val);
  }
  return { where: clauses.length? clauses.join(' AND '):'TRUE', params };
}

// --- OGC ---
app.get('/ogc/conformance', (_req,res)=>{
  res.json({ conformsTo: [
    'http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/core',
    'http://www.opengis.net/spec/ogcapi-features-3/1.0/conf/filter',
    'http://www.opengis.net/spec/cql2/1.0/conf/cql2-text'
  ]});
});

app.get('/ogc/collections', (_req,res)=>{
  res.json({collections:[
    {id:'features', itemType:'feature', title:'General Features'},
    {id:'open311_requests', itemType:'record', title:'Open311 Service Requests'}
  ]});
});

app.get('/ogc/queryables', (_req,res)=>{
  res.json({ type:'Queryables', properties: {
    class:{type:'string'},
    score:{type:'number'},
    status:{type:'string'},
    service_code:{type:'string'}
  }});
});

app.get('/ogc/collections/features/items', async (req,res)=>{
  const bbox = parseBBox(String(req.query.bbox||''));
  const dt = parseDatetimeRange(String(req.query.datetime||''));
  const { where, params } = safeFilterToSQL(String(req.query.filter||''), 'features');
  let sql = `SELECT id, properties, ST_AsGeoJSON(geom)::json AS geometry, created_at FROM features WHERE ${where}`;
  if(bbox){ sql += ` AND geom && ST_MakeEnvelope($${params.length+1},$${params.length+2},$${params.length+3},$${params.length+4},4326)`; params.push(bbox[0],bbox[1],bbox[2],bbox[3]); }
  if(dt?.from){ sql += ` AND created_at >= $${params.length+1}`; params.push(dt.from); }
  if(dt?.to){ sql += ` AND created_at <= $${params.length+1}`; params.push(dt.to); }
  if(dt?.at){ sql += ` AND date_trunc('day', created_at)=date_trunc('day', $${params.length+1}::timestamptz)`; params.push(dt.at); }
  sql += ` ORDER BY created_at DESC LIMIT ${Math.min(parseInt(req.query.limit||'100'),1000)}`;
  const r = await pool.query(sql, params);
  res.json({ type:'FeatureCollection', features: r.rows.map(row=>({ type:'Feature', id:row.id, properties: row.properties, geometry: row.geometry, created_at: row.created_at }))});
});

app.get('/ogc/collections/open311_requests/items', async (req,res)=>{
  const dt = parseDatetimeRange(String(req.query.datetime||''));
  const { where, params } = safeFilterToSQL(String(req.query.filter||''), 'open311_requests');
  let sql = `SELECT service_request_id, service_code, status, lat, lon, attributes, requested_datetime FROM open311_requests WHERE ${where}`;
  if(dt?.from) { sql += ` AND requested_datetime >= $${params.length+1}`; params.push(dt.from); }
  if(dt?.to)   { sql += ` AND requested_datetime <= $${params.length+1}`; params.push(dt.to); }
  if(dt?.at)   { sql += ` AND date_trunc('day', requested_datetime)=date_trunc('day', $${params.length+1}::timestamptz)`; params.push(dt.at); }
  sql += ` ORDER BY requested_datetime DESC LIMIT ${Math.min(parseInt(req.query.limit||'100'),1000)}`;
  const r = await pool.query(sql, params);
  res.json({ type:'FeatureCollection', features: r.rows.map(row=>({ type:'Feature', geometry: (row.lon!=null&&row.lat!=null)?{type:'Point',coordinates:[row.lon,row.lat]}:null, properties: row, created_at: row.requested_datetime }))});
});

// ingest + open311
app.post('/geojson/ingest', async (req,res)=>{
  const fc = req.body;
  if(!fc || fc.type!=='FeatureCollection' || !Array.isArray(fc.features)) return res.status(400).json({error:'Expected FeatureCollection'});
  const client = await pool.connect();
  try{
    await client.query('BEGIN');
    for(const f of fc.features){
      await client.query("INSERT INTO features (properties, geom, created_at) VALUES ($1, ST_SetSRID(ST_GeomFromGeoJSON($2),4326), now())", [f.properties||{}, JSON.stringify(f.geometry||{})]);
    }
    await client.query('COMMIT');
  }catch(e){
    await client.query('ROLLBACK'); throw e;
  }finally{ client.release(); }
  res.json({ok:true, inserted: fc.features.length});
});

// --- STAC ---
app.get('/stac', (_req,res)=>res.json({ stac_version:'1.0.0', type:'Catalog', id:'nusuj', description:'NUSUJ STAC Catalog' }));
app.get('/stac/collections', async (_req,res)=>{
  const r = await pool.query('SELECT id, description, bbox, license FROM stac_collections ORDER BY id');
  res.json({collections: r.rows});
});
app.post('/stac/search', async (req,res)=>{
  const { collections, datetime, bbox } = req.body||{};
  const params=[]; let where='TRUE';
  if(collections && Array.isArray(collections) && collections.length){
    where += ` AND collection = ANY($${params.length+1})`; params.push(collections);
  }
  if(datetime){
    if(String(datetime).includes('/')){
      const [a,b]=String(datetime).split('/');
      if(a){ where += ` AND datetime >= $${params.length+1}`; params.push(a); }
      if(b){ where += ` AND datetime <= $${params.length+1}`; params.push(b); }
    }else{ where += ` AND date_trunc('day', datetime)=date_trunc('day',$${params.length+1}::timestamptz)`; params.push(datetime); }
  }
  if(bbox && Array.isArray(bbox) && bbox.length==4){
    where += ` AND geom && ST_MakeEnvelope($${params.length+1},$${params.length+2},$${params.length+3},$${params.length+4},4326)`;
    params.push(bbox[0],bbox[1],bbox[2],bbox[3]);
  }
  const r = await pool.query(`SELECT id, collection, ST_AsGeoJSON(geom)::json AS geometry, bbox, datetime, assets FROM stac_items WHERE ${where} ORDER BY datetime DESC LIMIT 500`, params);
  res.json({ type:'FeatureCollection', features: r.rows });
});

// --- KPIs ---
app.get('/kpi/definitions', (_req,res)=>{
  const p = path.join(__dirname, '..','..','kpi','definitions.json');
  const j = fs.readFileSync(p, 'utf-8'); res.json(JSON.parse(j));
});

// Dispatch compute: some KPIs from DB, others from provided params
app.post('/kpi/compute', async (req,res)=>{
  const { kpi_id, geometry, params={} } = req.body||{};
  try{
    if(kpi_id==='visual_pollution_rate'){
      // count of open311 visual cases per km2 in an optional polygon
      let sql = "SELECT count(*)::int AS c FROM open311_requests WHERE service_code='visual_pollution'";
      const qParams=[];
      if(geometry){
        sql = "SELECT count(*)::int AS c FROM open311_requests WHERE service_code='visual_pollution' AND ST_Intersects(ST_SetSRID(ST_GeomFromGeoJSON($1),4326), ST_SetSRID(ST_MakePoint(lon,lat),4326))";
        qParams.push(JSON.stringify(geometry));
      }
      const r = await pool.query(sql, qParams);
      const area_km2 = params.area_km2 || (geometry? null: null);
      if(!area_km2) return res.json({kpi_id, value: r.rows[0].c, unit:'cases', method:'count_only'});
      return res.json({kpi_id, value: r.rows[0].c/area_km2, unit:'cases/km2', method:'db_count/area'});
    }
    if(kpi_id==='bus_stop_density'){
      // expects params.stops_count and area_km2
      const c = Number(params.stops_count||0), a = Number(params.area_km2||1);
      return res.json({kpi_id, value: c / max(a,1e-9), unit:'stops/km2', method:'params'});
    }
    if(kpi_id==='green_cover_ratio'){
      // expects params.area_green_km2 and params.area_urban_km2 OR ndvi_mean*area
      let g = params.area_green_km2;
      let u = params.area_urban_km2;
      if((g==null || u==null) && params.ndvi_mean!=null && params.area_urban_km2!=null){
        g = Number(params.ndvi_mean) * Number(params.area_urban_km2);
        u = Number(params.area_urban_km2);
      }
      if(g==null or u==null) return res.status(400).json({error:'need area_green_km2 and area_urban_km2 or ndvi_mean+area_urban_km2'});
      return res.json({kpi_id, value: (Number(g)/Number(u))*100.0, unit:'%', method:'params'});
    }
    if(kpi_id==='access_to_parks_10min'){
      const p10 = Number(params.pop_10min||0), total = Number(params.total_pop||1);
      return res.json({kpi_id, value: p10/max(total,1e-9)*100.0, unit:'%', method:'params'});
    }
    if(kpi_id==='lst_index'){
      const val = Number(params.lst_mean||0);
      return res.json({kpi_id, value: val, unit:'°C', method:'params'});
    }
    return res.status(400).json({error:'unknown kpi_id'});
  }catch(e){
    return res.status(500).json({error:String(e)});
  }
});

app.get('/health', (_req,res)=>res.json({status:'ok'}));

app.listen(4000, ()=>console.log("NUSUJ API v5.2 on :4000"));
