
'use client';
import useSWR from 'swr';
import MapView from '../../../components/MapView';
import { useState } from 'react';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000';
const fetcher=(u:string)=>fetch(u).then(r=>r.json());

export default function Viewer({id}:{id:string}){
  const {data} = useSWR(`/api/story?id=${id}`, fetcher);
  const [step, setStep] = useState(0);
  if(!data) return <div>تحميل القصة…</div>;
  const sec = data.sections?.[step];
  return (
    <div>
      <h2>{data.title}</h2>
      <MapView center={sec?.camera?.center||[46.7,24.7]} zoom={sec?.camera?.zoom||10} />
      <div style={{marginTop:12, display:'flex', gap:8}}>
        {data.sections?.map((_:any,i:number)=>(<button key={i} onClick={()=>setStep(i)} style={{padding:'6px 10px'}}>{i+1}</button>))}
      </div>
      <p style={{opacity:.7}}>طبقات OGC/STAC من: {API_BASE}</p>
    </div>
  );
}
