
'use client';
import { useState } from 'react';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000';

export default function Compute(){
  const [kpi, setKpi] = useState('green_cover_ratio');
  const [params, setParams] = useState<any>({ ndvi_mean: 0.35, area_urban_km2: 12 });
  const [geometry, setGeometry] = useState<string>('');
  const [out, setOut] = useState<any>(null);

  async function run(){
    const body:any = { kpi_id: kpi, params };
    if(geometry){ try{ body.geometry = JSON.parse(geometry); }catch(e){} }
    const r = await fetch(`${API_BASE}/kpi/compute`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(body)});
    setOut(await r.json());
  }

  return (
    <div>
      <h2>حساب KPI</h2>
      <div style={{display:'grid',gap:8,maxWidth:700}}>
        <label>اختر المؤشر:
          <select value={kpi} onChange={e=>setKpi(e.target.value)}>
            <option value="green_cover_ratio">green_cover_ratio</option>
            <option value="access_to_parks_10min">access_to_parks_10min</option>
            <option value="bus_stop_density">bus_stop_density</option>
            <option value="visual_pollution_rate">visual_pollution_rate</option>
            <option value="lst_index">lst_index</option>
          </select>
        </label>
        <label>Params (JSON):
          <textarea rows={6} value={JSON.stringify(params,null,2)} onChange={e=>{ try{ setParams(JSON.parse(e.target.value)); }catch{}}} />
        </label>
        <label>Geometry (Polygon GeoJSON — اختياري):
          <textarea rows={6} placeholder='{"type":"Polygon","coordinates":[...]}' value={geometry} onChange={e=>setGeometry(e.target.value)} />
        </label>
        <button onClick={run}>Compute</button>
        <pre>{JSON.stringify(out,null,2)}</pre>
      </div>
    </div>
  );
}
