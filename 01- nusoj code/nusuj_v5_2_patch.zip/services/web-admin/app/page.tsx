
import Link from 'next/link';
export default function P(){
  return (
    <div>
      <h1>لوحة الإدارة — NUSUJ v5.2</h1>
      <ul>
        <li><Link href="/story/city-story">Story Maps</Link></li>
        <li><Link href="/conformance">Conformance Viewer</Link></li>
        <li><Link href="/kpi">لوحة المؤشرات (التعريفات)</Link></li>
        <li><Link href="/kpi/compute">حساب المؤشرات (جديد)</Link></li>
        <li><Link href="/query">Query Builder</Link></li>
      </ul>
    </div>
  );
}
