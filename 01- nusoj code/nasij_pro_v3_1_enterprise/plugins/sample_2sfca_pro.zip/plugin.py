
def info():
    return {"name":"2SFCA Pro","desc":"Enhanced catchment accessibility with decay and multi-tier capacity"}
