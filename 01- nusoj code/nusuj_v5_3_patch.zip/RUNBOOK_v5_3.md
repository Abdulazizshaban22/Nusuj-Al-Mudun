
# NUSUJ v5.3 — Citizen PWA + Open311 Production Wiring

## ما الجديد
- **TWA/PWA Citizen**: manifest + service worker + صفحات (Consent/Report/Notifications).
- **Open311 Upload**: `POST /open311/upload` (multipart) يعيد `url` يمكن تمريره كـ `attributes.photo_url` عند إنشاء الطلب.
- **Open311 Create**: `POST /open311/requests` (كما في v5.1/5.2) لكن الآن مدعوم بصور.
- **قابلية الإشعارات**: صفحة `/notifications` تطلب الإذن؛ الاستكمال الخلفي (VAPID/APNs) لاحقًا.

## التشغيل
1) دمج patch داخل المستودع.
2) بناء وتشغيل:
```bash
docker compose -f docker-compose.yml -f docker-compose.override.yml up --build
# citizen → http://localhost:3100  | api → http://localhost:4000
```
3) من citizen:
   - افتح `/consent` واقبل السياسة.
   - اذهب إلى `/report` وارفع صورة + حدّد الموقع (أو استخدم "موقعي").
   - أرسل البلاغ → تحقق من استجابة JSON.

## ملاحظات أمن/خصوصية
- الرفع المحلي لأغراض التطوير فقط. للإنتاج استخدم S3/أوبجكت ستوريج مع صلاحيات مؤقتة (STS) وسياسات دورة حياة.
- طبّق HTTPS + HSTS + CSP وسياسة ملفات تعريف الارتباط.
- دمج الهوية (Nafath/Keycloak OIDC) يأتي في الطور السيادي.
