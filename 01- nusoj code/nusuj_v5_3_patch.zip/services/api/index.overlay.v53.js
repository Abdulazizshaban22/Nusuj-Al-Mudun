
import express from 'express';
import bodyParser from 'body-parser';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import url from 'url';
import multer from 'multer';
import pkg from 'pg';

const { Pool } = pkg;
const pool = new Pool({
  host: process.env.PGHOST||'db',
  port: +(process.env.PGPORT||5432),
  user: process.env.PGUSER||'nusuj',
  password: process.env.PGPASSWORD||'nusuj',
  database: process.env.PGDATABASE||'nusuj',
  max: 10
});

const app = express();
app.use(bodyParser.json({limit:'10mb'}));
app.use(cors({origin:true, credentials:true}));

// static uploads (dev only; for prod use S3 or object storage)
const UPLOAD_DIR = path.join(process.cwd(), 'uploads');
if(!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, {recursive:true});
app.use('/uploads', express.static(UPLOAD_DIR));
const storage = multer.diskStorage({
  destination: (_req, _file, cb)=>cb(null, UPLOAD_DIR),
  filename: (_req, file, cb)=>{
    const safe = Date.now() + '_' + file.originalname.replace(/[^a-zA-Z0-9_.-]/g,'_');
    cb(null, safe);
  }
});
const upload = multer({ storage });

// health
app.get('/health', (_req,res)=>res.json({status:'ok', uploads:true}));

// Open311: upload photo (returns URL)
app.post('/open311/upload', upload.single('photo'), (req,res)=>{
  if(!req.file) return res.status(400).json({error:'no file'});
  const urlp = `/uploads/${req.file.filename}`;
  res.json({ ok:true, url: urlp });
});

// Open311: create request (with optional photo_url in attributes)
app.post('/open311/requests', async (req,res)=>{
  const { service_code, status='open', lat=null, lon=null, attributes={} } = req.body||{};
  const r = await pool.query('INSERT INTO open311_requests (service_code,status,lat,lon,attributes) VALUES ($1,$2,$3,$4,$5) RETURNING service_request_id, requested_datetime', [service_code,status,lat,lon,attributes]);
  res.json({ service_request_id: r.rows[0].service_request_id, status, service_code, lat, lon, attributes, requested_datetime: r.rows[0].requested_datetime });
});

// OGC items for open311 (listing)
app.get('/ogc/collections/open311_requests/items', async (req,res)=>{
  const filter = String(req.query.filter||'');
  const dt = String(req.query.datetime||'');
  let where = 'TRUE'; const params=[];
  if(filter.includes("status='open'")){ where += ' AND status=$1'; params.push('open'); }
  let sql = `SELECT service_request_id, service_code, status, lat, lon, attributes, requested_datetime FROM open311_requests WHERE ${where} ORDER BY requested_datetime DESC LIMIT 200`;
  const r = await pool.query(sql, params);
  res.json({ type:'FeatureCollection', features: r.rows.map(row=>({ type:'Feature', geometry:(row.lon!=null&&row.lat!=null)?{type:'Point',coordinates:[row.lon,row.lat]}:null, properties: row }))});
});

export default app;
