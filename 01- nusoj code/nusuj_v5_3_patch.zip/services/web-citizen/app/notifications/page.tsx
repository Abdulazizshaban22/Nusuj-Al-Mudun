
'use client';
export default function Notif(){
  async function enable(){
    if(!('Notification' in window)) return alert('المتصفح لا يدعم الإشعارات');
    const perm = await Notification.requestPermission();
    alert('حالة الإذن: ' + perm);
    // subscription will be handled by sw.js + backend (VAPID/APNs) لاحقًا
  }
  return (
    <main style={{padding:16}}>
      <h2>الإشعارات</h2>
      <p>يمكنك تفعيل إشعارات الويب (iOS 16.4+ بعد إضافة الموقع إلى الشاشة الرئيسية).</p>
      <button onClick={enable}>تفعيل</button>
    </main>
  );
}
