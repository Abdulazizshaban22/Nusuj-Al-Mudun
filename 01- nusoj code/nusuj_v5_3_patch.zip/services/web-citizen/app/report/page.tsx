
'use client';
import { useState } from 'react';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000';

export default function Report(){
  const [file, setFile] = useState<File|null>(null);
  const [lat, setLat] = useState<string>('');
  const [lon, setLon] = useState<string>('');
  const [service, setService] = useState<string>('visual_pollution');
  const [resTxt, setResTxt] = useState<string>('');

  async function submit(){
    // simple PDPL check
    if(localStorage.getItem('pdpl_consent_v1')!=='yes'){
      alert('يرجى الموافقة على سياسة الخصوصية أولًا');
      return;
    }
    let photo_url = null;
    if(file){
      const fd = new FormData();
      fd.append('photo', file);
      const up = await fetch(`${API_BASE}/open311/upload`, { method:'POST', body: fd });
      const jj = await up.json();
      photo_url = jj.url;
    }
    const r = await fetch(`${API_BASE}/open311/requests`, {
      method:'POST',
      headers:{'content-type':'application/json'},
      body: JSON.stringify({
        service_code: service,
        status:'open',
        lat: lat? Number(lat): null,
        lon: lon? Number(lon): null,
        attributes: { photo_url }
      })
    });
    const j = await r.json();
    setResTxt(JSON.stringify(j,null,2));
  }

  function useMyLocation(){
    navigator.geolocation.getCurrentPosition(p=>{
      setLat(String(p.coords.latitude));
      setLon(String(p.coords.longitude));
    }, ()=>alert('تعذّر الحصول على الموقع'));
  }

  return (
    <main style={{padding:16, display:'grid', gap:12, maxWidth:520}}>
      <h2>رفع بلاغ (Open311)</h2>
      <label>نوع الخدمة:
        <select value={service} onChange={e=>setService(e.target.value)}>
          <option value="visual_pollution">تشوّه بصري</option>
          <option value="waste_overflow">تكدس نفايات</option>
          <option value="street_cleaning">نظافة شوارع</option>
        </select>
      </label>
      <label>صورة البلاغ: <input type="file" accept="image/*" onChange={e=>setFile(e.target.files?.[0]||null)} /></label>
      <div style={{display:'flex', gap:8}}>
        <label>Lat: <input value={lat} onChange={e=>setLat(e.target.value)} placeholder="24.7136" /></label>
        <label>Lon: <input value={lon} onChange={e=>setLon(e.target.value)} placeholder="46.6753" /></label>
        <button onClick={useMyLocation}>موقعي</button>
      </div>
      <button onClick={submit}>إرسال البلاغ</button>
      <pre style={{background:'#081018', padding:12, borderRadius:8, overflow:'auto'}}>{resTxt}</pre>
      <p style={{opacity:.7, fontSize:12}}>قد يتم رفع الصور إلى خادم المنصة لأغراض المعالجة. لا تُخزّن أي بيانات حساسة خارج الغرض المعلن.</p>
    </main>
  );
}
