
import Link from 'next/link';
export default function Home(){
  return (
    <main style={{padding:16}}>
      <h1>تطبيق نُسُج للمواطن — v5.3</h1>
      <ul>
        <li><Link href="/consent">سياسة الخصوصية والموافقة (PDPL)</Link></li>
        <li><Link href="/report">رفع بلاغ (Open311)</Link></li>
        <li><Link href="/notifications">الإشعارات</Link></li>
      </ul>
    </main>
  );
}
