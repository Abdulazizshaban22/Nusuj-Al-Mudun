
'use client';
import { useState, useEffect } from 'react';

export default function Consent(){
  const [agree, setAgree] = useState(false);
  useEffect(()=>{
    const v = localStorage.getItem('pdpl_consent_v1');
    if(v==='yes') setAgree(true);
  },[]);
  function accept(){
    localStorage.setItem('pdpl_consent_v1','yes');
    setAgree(true);
    alert('تم تسجيل الموافقة — يمكنك الآن استخدام كل الميزات.');
  }
  return (
    <main style={{padding:16}}>
      <h2>الخصوصية وفق PDPL</h2>
      <p>نوضح الغرض من جمع البيانات (الموقع، صورة البلاغ) وحقوقك في النفاذ والتصحيح والحذف وحقك في الاعتراض. لا تتم مشاركة بياناتك إلا مع الجهات المختصة لغرض معالجة البلاغ.</p>
      <p>يمكنك سحب الموافقة في أي وقت من الإعدادات.</p>
      {agree? <p style={{color:'#76e0a1'}}>✅ موافق — تم تفعيل جميع الميزات.</p> : <button onClick={accept}>أوافق</button>}
    </main>
  );
}
