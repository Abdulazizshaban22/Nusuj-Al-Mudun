
export const metadata = {
  title: 'NUSUJ Citizen v5.3',
  manifest: '/manifest.webmanifest',
  viewport: { width:'device-width', initialScale:1, viewportFit:'cover' }
};
export default function R({children}:{children:React.ReactNode}){
  return (
    <html lang='ar' dir='rtl'>
      <body style={{background:'#0b0f14',color:'#e7eef7'}}>
        <script dangerouslySetInnerHTML={{__html:`
          if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
              navigator.serviceWorker.register('/sw.js').catch(()=>{});
            });
          }
        `}}/>
        {children}
      </body>
    </html>
  );
}
