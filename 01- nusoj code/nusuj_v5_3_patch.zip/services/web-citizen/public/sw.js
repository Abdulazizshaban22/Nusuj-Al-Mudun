
self.addEventListener('install', (e)=>{
  self.skipWaiting();
  e.waitUntil(caches.open('nusuj-v1').then(c=>c.addAll(['/','/manifest.webmanifest'])));
});
self.addEventListener('activate', (e)=>{
  e.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', (e)=>{
  e.respondWith(caches.match(e.request).then(r=> r || fetch(e.request)));
});
self.addEventListener('push', (event)=>{
  const data = event.data ? event.data.json() : { title:'إشعار نُسُج', body:'تحديث جديد' };
  event.waitUntil(self.registration.showNotification(data.title, { body: data.body }));
});
