
import pkg from 'pg';
const { Pool } = pkg;
export const pool = new Pool({
  host: process.env.PGHOST||'localhost',
  port: +(process.env.PGPORT||5432),
  user: process.env.PGUSER||'nusuj',
  password: process.env.PGPASSWORD||'nusuj',
  database: process.env.PGDATABASE||'nusuj',
  max: 10
});
