
import express from 'express';
import bodyParser from 'body-parser';
import fs from 'fs';
import path from 'path';
import { pool } from './db.js';

const app = express();
app.use(bodyParser.json());

function parseBBox(s){
  if(!s) return null;
  const p = s.split(',').map(Number);
  if(p.length!==4 || p.some(isNaN)) return null;
  return p; // [minx,miny,maxx,maxy]
}
function parseDatetimeRange(d){
  if(!d) return null;
  if(d.includes('/')){
    const [a,b]=d.split('/'); return {from: a||null, to: b||null};
  }
  return {at: d};
}
function safeFilterToSQL(filter, table){
  // supported keys: class (JSONB), score (JSONB numeric), status/service_code (open311), simple ANDs
  if(!filter) return {where:'TRUE', params:[]};
  const parts = filter.split(/\s+AND\s+/i);
  const clauses = []; const params = [];
  for(const p of parts){
    const m = p.trim().match(/^([A-Za-z0-9_.-]+)\s*(=|!=|>=|<=|>|<)\s*(.+)$/);
    if(!m) continue;
    let [,key,op,raw]=m;
    let col = null; let cast = '';
    if(table==='features'){
      if(key==='class'){ col = "(properties->>'class')"; }
      else if(key==='score'){ col = "(properties->>'score')::double precision"; }
    }else if(table==='open311_requests'){
      if(key==='status'){ col = 'status'; }
      else if(key==='service_code'){ col = 'service_code'; }
    }
    if(!col) continue;
    let val = raw;
    if(raw.startsWith("'") && raw.endsWith("'")) val = raw.slice(1,-1);
    clauses.push(`${col} ${op==='!='?'<>':op} $${params.length+1}`);
    params.push(val);
  }
  return { where: clauses.length? clauses.join(' AND '):'TRUE', params };
}

// Conformance stays as in v5.0
app.get('/ogc/conformance', (_req,res)=>{
  res.json({ conformsTo: [
    'http://www.opengis.net/spec/ogcapi-features-1/1.0/conf/core',
    'http://www.opengis.net/spec/ogcapi-features-3/1.0/conf/filter',
    'http://www.opengis.net/spec/cql2/1.0/conf/cql2-text'
  ]});
});

app.get('/ogc/collections', (_req,res)=>{
  res.json({collections:[
    {id:'features', itemType:'feature', title:'General Features'},
    {id:'open311_requests', itemType:'record', title:'Open311 Service Requests'}
  ]});
});

app.get('/ogc/collections/features/items', async (req,res)=>{
  const bbox = parseBBox(String(req.query.bbox||''));
  const dt = parseDatetimeRange(String(req.query.datetime||''));
  const { where, params } = safeFilterToSQL(String(req.query.filter||''), 'features');
  let sql = `SELECT id, properties, ST_AsGeoJSON(geom)::json AS geometry, created_at FROM features WHERE ${where}`;
  if(bbox) sql += ` AND geom && ST_MakeEnvelope($${params.length+1},$${params.length+2},$${params.length+3},$${params.length+4},4326)`; 
  if(bbox) params.push(bbox[0],bbox[1],bbox[2],bbox[3]);
  if(dt?.from) { sql += ` AND created_at >= $${params.length+1}`; params.push(dt.from); }
  if(dt?.to)   { sql += ` AND created_at <= $${params.length+1}`; params.push(dt.to); }
  if(dt?.at)   { sql += ` AND date_trunc('day', created_at)=date_trunc('day', $${params.length+1}::timestamptz)`; params.push(dt.at); }
  sql += ` ORDER BY created_at DESC LIMIT ${Math.min(parseInt(req.query.limit||'100'),1000)}`;
  const r = await pool.query(sql, params);
  res.json({ type:'FeatureCollection', features: r.rows.map(row=>({ type:'Feature', id:row.id, properties: row.properties, geometry: row.geometry, created_at: row.created_at }))});
});

app.get('/ogc/collections/open311_requests/items', async (req,res)=>{
  const dt = parseDatetimeRange(String(req.query.datetime||''));
  const { where, params } = safeFilterToSQL(String(req.query.filter||''), 'open311_requests');
  let sql = `SELECT service_request_id, service_code, status, lat, lon, attributes, requested_datetime FROM open311_requests WHERE ${where}`;
  if(dt?.from) { sql += ` AND requested_datetime >= $${params.length+1}`; params.push(dt.from); }
  if(dt?.to)   { sql += ` AND requested_datetime <= $${params.length+1}`; params.push(dt.to); }
  if(dt?.at)   { sql += ` AND date_trunc('day', requested_datetime)=date_trunc('day', $${params.length+1}::timestamptz)`; params.push(dt.at); }
  sql += ` ORDER BY requested_datetime DESC LIMIT ${Math.min(parseInt(req.query.limit||'100'),1000)}`;
  const r = await pool.query(sql, params);
  res.json({ type:'FeatureCollection', features: r.rows.map(row=>({ type:'Feature', geometry: (row.lon!=null&&row.lat!=null)?{type:'Point',coordinates:[row.lon,row.lat]}:null, properties: row, created_at: row.requested_datetime }))});
});

app.post('/geojson/ingest', async (req,res)=>{
  const fc = req.body;
  if(!fc || fc.type!=='FeatureCollection' || !Array.isArray(fc.features)) return res.status(400).json({error:'Expected FeatureCollection'});
  const client = await pool.connect();
  try{
    await client.query('BEGIN');
    for(const f of fc.features){
      await client.query("INSERT INTO features (properties, geom, created_at) VALUES ($1, ST_SetSRID(ST_GeomFromGeoJSON($2),4326), now())", [f.properties||{}, JSON.stringify(f.geometry||{})]);
    }
    await client.query('COMMIT');
  }catch(e){
    await client.query('ROLLBACK'); throw e;
  }finally{ client.release(); }
  res.json({ok:true, inserted: fc.features.length});
});

// STAC endpoints backed by DB
app.get('/stac', (_req,res)=>res.json({ stac_version:'1.0.0', type:'Catalog', id:'nusuj', description:'NUSUJ STAC Catalog' }));
app.get('/stac/collections', async (_req,res)=>{
  const r = await pool.query('SELECT id, description, bbox, license FROM stac_collections ORDER BY id');
  res.json({collections: r.rows});
});
app.post('/stac/search', async (req,res)=>{
  const { collections, datetime, bbox } = req.body||{};
  const params=[]; let where='TRUE';
  if(collections && Array.isArray(collections) && collections.length){
    where += ` AND collection = ANY($${params.length+1})`; params.push(collections);
  }
  if(datetime){
    if(String(datetime).includes('/')){
      const [a,b]=String(datetime).split('/');
      if(a){ where += ` AND datetime >= $${params.length+1}`; params.push(a); }
      if(b){ where += ` AND datetime <= $${params.length+1}`; params.push(b); }
    }else{ where += ` AND date_trunc('day', datetime)=date_trunc('day',$${params.length+1}::timestamptz)`; params.push(datetime); }
  }
  if(bbox && Array.isArray(bbox) && bbox.length==4){
    where += ` AND geom && ST_MakeEnvelope($${params.length+1},$${params.length+2},$${params.length+3},$${params.length+4},4326)`;
    params.push(*bbox)
  }
  const r = await pool.query(f"SELECT id, collection, ST_AsGeoJSON(geom)::json AS geometry, bbox, datetime, assets FROM stac_items WHERE {where} ORDER BY datetime DESC LIMIT 500", params);
  res.json({ type:'FeatureCollection', features: r.rows });
});

// Open311 create
app.post('/open311/requests', async (req,res)=>{
  const { service_code, status='open', lat=null, lon=null, attributes={} } = req.body||{};
  const r = await pool.query('INSERT INTO open311_requests (service_code,status,lat,lon,attributes) VALUES ($1,$2,$3,$4,$5) RETURNING service_request_id, requested_datetime', [service_code,status,lat,lon,attributes]);
  res.json({ service_request_id: r.rows[0].service_request_id, status, service_code, lat, lon, requested_datetime: r.rows[0].requested_datetime });
});

app.get('/health', (_req,res)=>res.json({status:'ok'}));

export default app;
