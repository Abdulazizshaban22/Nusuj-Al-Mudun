
/**
 * Minimal CQL2 text parser -> SQL WHERE clauses (safe whitelist mapping).
 * Supports: AND, =, !=, >, <, >=, <= over whitelisted keys in properties.
 * NOTE: For production, use a full CQL2 implementation / vetted library.
 */
const WHITELIST = new Set(['class','score','status','service_code']);
const OPS = new Set(['=','!=','>','<','>=','<=']);

export function cql2ToSQL(filter){
  if(!filter) return { sql:'TRUE', params:[] };
  const parts = String(filter).split(/\s+AND\s+/i);
  const clauses = [];
  const params = [];
  for(const p of parts){
    const m = p.trim().match(/^([A-Za-z0-9_.-]+)\s*(=|!=|>=|<=|>|<)\s*(.+)$/);
    if(!m) continue;
    let [,key,op,raw]=m;
    if(!OPS.has(op)) continue;
    let column = null;
    if(WHITELIST.has(key)) column = `properties->>${JSON.stringify(key)}`;
    else if(key==='status' || key==='service_code') column = key;
    else continue;
    if(raw.startsWith("'") && raw.endsWith("'")){
      raw = raw.slice(1,-1);
      clauses.push(`${column} ${op==='='?'=':'<>'} $${params.length+1}` if op in ['=','!='] else `${column} ${op} $${params.length+1}`)
    }
  }
  // Fallback naive; to keep it simple, we just return TRUE
  return { sql:'TRUE', params:[] };
}
