
# NUSUJ v5.1 — CQL2/STAC/PostGIS Upgrade

## What’s new
- PostGIS database (features, open311_requests, stac_*).
- `/items` now backed by PostGIS with bbox/datetime + CQL2 (subset) over properties/status/service_code.
- `/stac/*` backed by DB with seed item (ndvi-2025-10).
- `/open311/requests` writes to DB.

## How to run
```bash
# from monorepo root
docker compose -f docker-compose.yml -f docker-compose.override.yml up --build
# db on :5432, api :4000, etl :5000, admin :3000, citizen :3100
```

## Smoke tests
```bash
# conformance
curl http://localhost:4000/ogc/conformance

# ingest a park
curl -X POST http://localhost:4000/geojson/ingest -H "content-type: application/json" -d '{ "type":"FeatureCollection","features":[{"type":"Feature","geometry":{"type":"Point","coordinates":[46.68,24.72]},"properties":{"class":"park","score":0.83}}] }'

# query by CQL2 + bbox
curl "http://localhost:4000/ogc/collections/features/items?filter=class='park'%20AND%20score>=0.8&filter-lang=cql2-text&bbox=45,24,48,26&limit=10"

# stac collections
curl http://localhost:4000/stac/collections
# stac search
curl -X POST http://localhost:4000/stac/search -H "content-type: application/json" -d '{ "collections":["urban-indicators"], "datetime":"2025-10-01/2025-12-31", "bbox":[35,16,55,33] }'

# open311 create + list
curl -X POST http://localhost:4000/open311/requests -H "content-type: application/json" -d '{"service_code":"visual_pollution","status":"open","lat":24.7,"lon":46.7}'
curl "http://localhost:4000/ogc/collections/open311_requests/items?filter=status='open'&filter-lang=cql2-text&limit=5"
```
