
CREATE EXTENSION IF NOT EXISTS postgis;

-- features
CREATE TABLE IF NOT EXISTS features (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  properties JSONB NOT NULL DEFAULT '{}'::jsonb,
  geom geometry(GEOMETRY, 4326) NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS features_gix ON features USING GIST (geom);
CREATE INDEX IF NOT EXISTS features_props_idx ON features USING GIN (properties);
CREATE INDEX IF NOT EXISTS features_created_idx ON features (created_at);

-- open311
CREATE TABLE IF NOT EXISTS open311_requests (
  service_request_id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  service_code TEXT,
  status TEXT,
  lat DOUBLE PRECISION,
  lon DOUBLE PRECISION,
  attributes JSONB NOT NULL DEFAULT '{}'::jsonb,
  requested_datetime timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS open311_spatial_idx ON open311_requests (lat, lon);
CREATE INDEX IF NOT EXISTS open311_code_idx ON open311_requests (service_code);
CREATE INDEX IF NOT EXISTS open311_status_idx ON open311_requests (status);
CREATE INDEX IF NOT EXISTS open311_time_idx ON open311_requests (requested_datetime);

-- stac (minimal metadata for items/assets)
CREATE TABLE IF NOT EXISTS stac_collections (
  id TEXT PRIMARY KEY,
  description TEXT,
  bbox DOUBLE PRECISION[],
  license TEXT DEFAULT 'proprietary'
);

CREATE TABLE IF NOT EXISTS stac_items (
  id TEXT PRIMARY KEY,
  collection TEXT REFERENCES stac_collections(id) ON DELETE CASCADE,
  geom geometry(POLYGON,4326),
  bbox DOUBLE PRECISION[],
  datetime timestamptz,
  assets JSONB NOT NULL
);
CREATE INDEX IF NOT EXISTS stac_items_gix ON stac_items USING GIST (geom);
CREATE INDEX IF NOT EXISTS stac_items_time_idx ON stac_items (datetime);

-- seed small demo
INSERT INTO stac_collections (id, description, bbox) VALUES
('urban-indicators','Urban rasters (NDVI/LST)', ARRAY[35,16,55,33]) ON CONFLICT DO NOTHING;

INSERT INTO stac_items (id, collection, geom, bbox, datetime, assets) VALUES
('ndvi-2025-10', 'urban-indicators',
 ST_PolygonFromText('POLYGON((35 16,55 16,55 33,35 33,35 16))',4326),
 ARRAY[35,16,55,33],
 '2025-10-01T00:00:00Z',
 jsonb_build_object('cog', jsonb_build_object('href','s3://bucket/path/ndvi-2025-10.tif','type','image/tiff; application=geotiff; profile=cloud-optimized'))
) ON CONFLICT DO NOTHING;
