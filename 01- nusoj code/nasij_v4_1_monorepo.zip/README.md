# NASIJ v4 — المنصة الوطنية للنسيج الحضري
منصة ذكاء حضري (Urban Intelligence) بهيكل أحادي (Monorepo) يضم:
- **apps/web**: واجهة Next.js
- **services/api**: ‎NestJS API (RBAC/Keycloak-ready)
- **services/etl**: ‎FastAPI للخوارزميات المكانية (AHP/TOPSIS/DBSCAN، H3 لاحقًا)
- **infra**: ‏Docker Compose + مراقبة أساسية + Mosquitto + PostGIS + pgvector

> الهدف: تشغيل نسخة تطوير محلية سريعة، ثم التوسع لاحقًا نحو Terraform/ECS.

## التشغيل السريع
```bash
cp .env.example .env
docker compose up -d --build
# الواجهة: http://localhost:3000
# API:     http://localhost:4000
# ETL:     http://localhost:5000/docs
# DB:      postgresql://nasij:nasij@localhost:5432/nasij
# Grafana: http://localhost:3001 (admin/admin) — غيّرها لاحقًا
```
## المعمارية (مختصر)
- Traefik كعكس وكيل خفيف (اختياري في dev).
- PostGIS مع pgvector.
- Keycloak جاهز لكن غير مُفعّل افتراضيًا (لتسهيل بدء التطوير).
- Mosquitto MQTT كقناة إنترنت أشياء.
- Prometheus + Grafana أساسيان مع Dashboards تمهيدية.

## خرائط الطريق
- v4.1: تفعيل H3/Gi* + RBAC كامل + Story Studio.
- v4.2: Digital Twin لكل حي + Streaming Analytics.
- v4.3: Terraform/ECS + Secrets Manager + PDPL Audit.

---

## v4.1 (هذه الحزمة)
### ما الجديد؟
- **H3 + Gi\***: نقاط نهاية في ETL لحساب الخلايا والـHotspots.
- **RBAC جاهز للربط مع Keycloak**: التحقق من JWT عبر JWKS (`KEYCLOAK_JWKS_URL`) + `/secure/ping` في API.
- **Prometheus + Grafana**: `/metrics` لكل من API وETL + Dashboard جاهز.
- **PostGIS Ingest/Query**: `/db/h3/ingest` و`/db/h3/query` في ETL.

### المتغيرات الجديدة
- `KEYCLOAK_JWKS_URL` — عنوان JWKS من Keycloak (مثال: `http://keycloak:8080/realms/yourrealm/protocol/openid-connect/certs`)

### أمثلة سريعة
```bash
# حساب H3 index لنقطة:
curl -X POST http://localhost:5000/h3/index -H 'Content-Type: application/json' -d '{"lat":24.7136,"lng":46.6753,"res":8}'

# Gi* Hotspots على خلايا H3:
curl -X POST http://localhost:5000/h3/hotspots -H 'Content-Type: application/json' -d '{
  "items":[
    {"h3index":"8828308291fffff","value":10},
    {"h3index":"8828308291bffff","value":30},
    {"h3index":"88283082917ffff","value":5}
  ],
  "ring": 1
}'
```

### مراقبة
- Prometheus: http://localhost:9090
- Grafana: http://localhost:3001  (User: admin / Pass: admin) ← غيّرها فورًا
