from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import numpy as np
from typing import List, Optional, Dict
import os

# Prometheus
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

# H3 + Gi*
from h3 import h3
import psycopg
from esda import G_Local
import libpysal

app = FastAPI(title="NASIJ ETL", version="4.1.0")

# Prometheus metrics
REQS = Counter("etl_requests_total", "Total requests to ETL", ["endpoint"])
LAT = Histogram("etl_request_seconds", "Request latency seconds", ["endpoint"])

@app.get("/health")
def health():
    REQS.labels(endpoint="/health").inc()
    return {"status": "ok", "service": "etl", "version": "4.1.0"}

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

# ===== Fabric Index =====
class FabricInput(BaseModel):
    morphology: float  # 0..1
    environment: float # 0..1
    accessibility: float # 0..1
    weights: tuple[float, float, float] = (0.4, 0.3, 0.3)

@app.post("/fabric/index")
def fabric_index(inp: FabricInput):
    REQS.labels(endpoint="/fabric/index").inc()
    w = np.array(inp.weights, dtype=float)
    x = np.array([inp.morphology, inp.environment, inp.accessibility], dtype=float)
    w = w / w.sum()
    score = float(np.clip((w * x).sum(), 0.0, 1.0)) * 100.0
    return {"fabric_index": round(score, 2), "weights": w.tolist()}

@app.get("/fabric/demo")
def fabric_demo():
    REQS.labels(endpoint="/fabric/demo").inc()
    x = np.array([0.62, 0.48, 0.71])
    w = np.array([0.4, 0.3, 0.3])
    score = float(np.clip((w * x).sum(), 0.0, 1.0)) * 100.0
    return {"fabric_index": round(score, 2), "components": {"morphology":0.62,"environment":0.48,"accessibility":0.71}}

# ===== H3 utilities =====
class H3IndexIn(BaseModel):
    lat: float
    lng: float
    res: int

@app.post("/h3/index")
def h3_index(inp: H3IndexIn):
    REQS.labels(endpoint="/h3/index").inc()
    if not (0 <= inp.res <= 15):
        raise HTTPException(400, "Resolution must be 0..15")
    idx = h3.geo_to_h3(inp.lat, inp.lng, inp.res)
    return {"h3index": idx}

class H3HotspotItem(BaseModel):
    h3index: str
    value: float

class H3HotspotIn(BaseModel):
    items: List[H3HotspotItem]
    ring: int = 1

@app.post("/h3/hotspots")
def h3_hotspots(inp: H3HotspotIn):
    # Compute Getis-Ord Gi* on H3 cells using binary neighbor weights.
    REQS.labels(endpoint="/h3/hotspots").inc()
    cells = [it.h3index for it in inp.items]
    values = np.array([it.value for it in inp.items])
    if len(cells) != len(set(cells)):
        raise HTTPException(400, "Duplicate h3index detected")

    neighbors = {}
    cellset = set(cells)
    for c in cells:
        neigh = set(h3.k_ring(c, inp.ring)) & cellset
        neighbors[c] = list(neigh)

    w = libpysal.weights.W(neighbors, silence_warnings=True)
    w.transform = "R"  # row-standardized
    g = G_Local(values, w, star=True)  # Gi*

    out = [{"h3index": c, "z": float(z), "p": float(p)} for c, z, p in zip(cells, g.Zs, g.p_sim)]
    out.sort(key=lambda x: abs(x["z"]), reverse=True)
    return {"n": len(out), "results": out}

# ===== PostGIS ingestion =====
DB_URL = os.environ.get("DATABASE_URL")

class H3IngestItem(BaseModel):
    h3index: str
    props: Optional[dict] = None

class H3Ingest(BaseModel):
    items: List[H3IngestItem]

def _json_dump(v):
    import json as _j
    return _j.dumps(v) if v is not None else None

@app.post("/db/h3/ingest")
def db_h3_ingest(payload: H3Ingest):
    REQS.labels(endpoint="/db/h3/ingest").inc()
    if not DB_URL:
        raise HTTPException(500, "DATABASE_URL not set")
    with psycopg.connect(DB_URL) as con:
        with con.cursor() as cur:
            for it in payload.items:
                lat, lng = h3.h3_to_geo(it.h3index)
                cur.execute(
                    "INSERT INTO urban.h3_cells (h3index, centroid, props) VALUES (%s, ST_SetSRID(ST_Point(%s,%s),4326), COALESCE(%s,'{}'::jsonb)) ON CONFLICT (h3index) DO UPDATE SET props = EXCLUDED.props",
                    (it.h3index, lng, lat, _json_dump(it.props)),
                )
        con.commit()
    return {"inserted": len(payload.items)}

@app.get("/db/h3/query")
def db_h3_query(limit: int = 50):
    REQS.labels(endpoint="/db/h3/query").inc()
    if not DB_URL:
        raise HTTPException(500, "DATABASE_URL not set")
    with psycopg.connect(DB_URL) as con:
        rows = con.execute("SELECT h3index, ST_Y(centroid) AS lat, ST_X(centroid) AS lng, props FROM urban.h3_cells LIMIT %s", (limit,)).fetchall()
    return {"rows": [{"h3index": r[0], "lat": float(r[1]), "lng": float(r[2]), "props": r[3]} for r in rows]}