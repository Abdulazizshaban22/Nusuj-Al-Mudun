import 'reflect-metadata';
import { createServer } from 'http';
import { verifyToken, hasRole } from './auth';
import client, { Counter, Histogram, Registry } from 'prom-client';

const PORT = process.env.PORT || 4000;

const register = new Registry();
client.collectDefaultMetrics({ register });

const requestsTotal = new Counter({ name: 'api_requests_total', help: 'Total API requests', labelNames: ['route'] });
const latency = new Histogram({ name: 'api_request_seconds', help: 'API request latency', labelNames: ['route'] });
register.registerMetric(requestsTotal);
register.registerMetric(latency);

function json(res:any, code:number, obj:any){
  res.writeHead(code, {'Content-Type':'application/json'});
  res.end(JSON.stringify(obj));
}

const server = createServer(async (req, res) => {
  const url = req.url || '/';
  const endTimer = latency.labels(url).startTimer();
  try {
    if (url === '/health') {
      requestsTotal.labels('/health').inc();
      return json(res, 200, {status:'ok', service:'api', version:'4.1.0'});
    }
    if (url === '/metrics') {
      const metrics = await register.metrics();
      res.writeHead(200, {'Content-Type': register.contentType});
      res.end(metrics);
      return;
    }
    if (url.startsWith('/secure/ping')) {
      requestsTotal.labels('/secure/ping').inc();
      const auth = req.headers['authorization'];
      if (!auth || !auth.startsWith('Bearer ')) return json(res, 401, {error:'Missing bearer token'});
      const token = auth.split(' ')[1];
      try {
        const payload = await verifyToken(token);
        if (!hasRole(payload, 'municipality')) return json(res, 403, {error:'insufficient_role'});
        return json(res, 200, {ok:true, sub: payload.sub, role:'municipality'});
      } catch (e:any) {
        return json(res, 401, {error:'invalid_token', detail: e?.message});
      }
    }
    requestsTotal.labels('root').inc();
    return json(res, 200, {message:'NASIJ API v4.1 placeholder'});
  } finally {
    endTimer();
  }
});

server.listen(PORT, () => console.log('API on', PORT));