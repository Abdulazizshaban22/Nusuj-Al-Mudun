
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import webpush from 'web-push';
import pkg from 'pg';

const { Pool } = pkg;
const pool = new Pool({
  host: process.env.PGHOST||'db',
  port: +(process.env.PGPORT||5432),
  user: process.env.PGUSER||'nusuj',
  password: process.env.PGPASSWORD||'nusuj',
  database: process.env.PGDATABASE||'nusuj',
  max: 10
});

const app = express();
app.use(express.json({limit:'5mb'}));
app.use(helmet({
  contentSecurityPolicy: false, // keep simple; set full CSP at reverse proxy/CDN
  crossOriginEmbedderPolicy: false
}));
app.use(rateLimit({ windowMs: 60_000, max: 300 }));

// ---- S3 presign (PUT) ----
const s3 = new S3Client({
  region: process.env.AWS_REGION||'me-central-1',
  credentials: process.env.AWS_ACCESS_KEY_ID?{
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
  }:undefined
});
app.post('/upload/presign', async (req,res)=>{
  try{
    const { filename, contentType } = req.body||{};
    if(!filename) return res.status(400).json({error:'filename required'});
    const bucket = process.env.S3_BUCKET;
    const key = `uploads/${Date.now()}_${String(filename).replace(/[^a-zA-Z0-9_.-]/g,'_')}`;
    const cmd = new PutObjectCommand({ Bucket: bucket, Key: key, ContentType: contentType||'application/octet-stream' });
    const url = await getSignedUrl(s3, cmd, { expiresIn: 900 });
    const publicUrl = process.env.CF_DOMAIN ? `https://${process.env.CF_DOMAIN}/${key}` : null;
    res.json({ url, method:'PUT', key, publicUrl });
  }catch(e){
    res.status(500).json({error:String(e)});
  }
});

// ---- Web Push (VAPID) ----
const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY||'';
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY||'';
if(VAPID_PUBLIC && VAPID_PRIVATE){
  webpush.setVapidDetails(
    process.env.VAPID_SUBJECT||'mailto:admin@localhost',
    VAPID_PUBLIC, VAPID_PRIVATE
  );
}
app.get('/push/publicKey', (_req,res)=>res.json({ publicKey: VAPID_PUBLIC }));
app.post('/push/subscribe', async (req,res)=>{
  const sub = req.body;
  if(!sub?.endpoint || !sub?.keys) return res.status(400).json({error:'invalid subscription'});
  await pool.query(
    "INSERT INTO push_subscriptions (endpoint, keys) VALUES ($1,$2) ON CONFLICT (endpoint) DO UPDATE SET keys=EXCLUDED.keys",
    [sub.endpoint, sub.keys]
  );
  res.json({ok:true});
});
app.post('/push/test', async (req,res)=>{
  if(!VAPID_PRIVATE) return res.status(500).json({error:'VAPID not configured'});
  const r = await pool.query("SELECT endpoint, keys FROM push_subscriptions ORDER BY created_at DESC LIMIT 50");
  const payload = JSON.stringify({ title:'إشعار نُسُج', body: req.body?.body||'اختبار تنبيهات' });
  const results = [];
  for(const row of r.rows){
    try{
      await webpush.sendNotification({ endpoint: row.endpoint, keys: row.keys }, payload);
      results.push({ endpoint: row.endpoint, ok:true });
    }catch(e){ results.push({ endpoint: row.endpoint, ok:false, error: String(e) }); }
  }
  res.json({sent: results.length, results});
});

export default app;
