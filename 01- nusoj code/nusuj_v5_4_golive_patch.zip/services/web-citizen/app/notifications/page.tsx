
'use client';
import { useEffect, useState } from 'react';

const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000';

async function subscribePush(){
  if(!('serviceWorker' in navigator) || !('PushManager' in window)){
    alert('متصفحك لا يدعم Web Push'); return null;
  }
  const reg = await navigator.serviceWorker.ready;
  const pub = await fetch(`${API_BASE}/push/publicKey`).then(r=>r.json());
  const sub = await reg.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(pub.publicKey)
  });
  await fetch(`${API_BASE}/push/subscribe`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify(sub) });
  return sub;
}

function urlBase64ToUint8Array(base64String){
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

export default function Notif(){
  const [state, setState] = useState('');
  useEffect(()=>{ setState(Notification.permission); },[]);
  async function enable(){
    const perm = await Notification.requestPermission();
    setState(perm);
    if(perm==='granted'){ await subscribePush(); alert('تم الاشتراك في الإشعارات'); }
  }
  async function test(){
    await fetch(`${API_BASE}/push/test`, { method:'POST', headers:{'content-type':'application/json'}, body: JSON.stringify({body:'مرحبا! هذا اختبار تنبيه من نُسُج'}) });
    alert('تم إرسال اختبار إلى جميع المشتركين');
  }
  return (
    <main style={{padding:16}}>
      <h2>الإشعارات</h2>
      <p>الحالة: {state||'غير معروف'}</p>
      <button onClick={enable}>تفعيل</button>
      <button onClick={test} style={{marginInlineStart:8}}>إرسال اختبار</button>
      <p style={{opacity:.7}}>لـ iOS يلزم إضافة التطبيق للشاشة الرئيسية (iOS 16.4+).</p>
    </main>
  );
}
