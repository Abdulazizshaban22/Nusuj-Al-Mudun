
# Security Headers (Production)

- **HSTS**: `Strict-Transport-Security: max-age=31536000; includeSubDomains; preload`
- **CSP** (example — tighten per domain):
  `Content-Security-Policy: default-src 'self'; img-src 'self' data: https:; script-src 'self' 'nonce-<RANDOM>'; style-src 'self' 'unsafe-inline'; connect-src 'self' https:`
- **Referrer-Policy**: `no-referrer`
- **X-Content-Type-Options**: `nosniff`
- **X-Frame-Options**: `DENY`
- **Permissions-Policy**: set only required features.
