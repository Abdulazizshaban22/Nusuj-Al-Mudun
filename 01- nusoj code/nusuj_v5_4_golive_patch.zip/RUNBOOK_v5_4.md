
# NUSUJ v5.4 — Go‑Live Pack

يشمل:
1) **S3 + CloudFront**: رفع الصور عبر **Presigned URL** (PUT)؛ التوزيع عبر CloudFront + OAC. 
2) **Web Push** (VAPID): اشتراك/اختبار، تخزين الاشتراكات في Postgres.
3) **أمن وخصوصية**: Helmet + Rate-limit؛ ملفات إرشادات لتفعيل HSTS/CSP. صفحة حقوق البيانات.
4) **Observability**: Loki/Tempo/Grafana overlay سريع.

## المتغيّرات (env)
```
AWS_REGION=me-central-1
S3_BUCKET=your-bucket
CF_DOMAIN=cdn.example.com   # إن وُجد
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
VAPID_PUBLIC_KEY=...
VAPID_PRIVATE_KEY=...
VAPID_SUBJECT=mailto:security@example.com
```

## إنشاء مفاتيح VAPID
يمكن باستخدام حزمة `web-push`:
```bash
node -e "console.log(require('web-push').generateVAPIDKeys())"
```

## التشغيل
```bash
# الخدمات الرئيسة
docker compose -f docker-compose.yml -f docker-compose.override.yml up --build

# المراقبة
docker compose -f docker-compose.observability.yml up -d
# Grafana → http://localhost:3001  (admin / admin)
```

## ملاحظات إنتاج
- ارفع الصور إلى S3 عبر presign، وقدّمها من CloudFront مع **OAC** وتقييد الوصول المباشر إلى S3.
- فعّل HTTPS، HSTS، CSP؛ أدر الأسرار عبر AWS Secrets Manager/KMS.
- اربط الهوية: Keycloak OIDC للأدوار المؤسسية؛ وانظر وثائق نفاذ (SSO و/أو تحقق) للهوية الوطنية.
- اربط Promtail بمسارات سجلات الحاويات الفعلية في إنتاجك أو استخدم OTel.
