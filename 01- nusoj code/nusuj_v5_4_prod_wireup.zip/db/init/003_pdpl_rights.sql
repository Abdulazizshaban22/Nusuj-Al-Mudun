
CREATE TABLE IF NOT EXISTS pdpl_requests (
  id BIGSERIAL PRIMARY KEY,
  request_type TEXT NOT NULL, -- access|rectify|erase|withdraw
  subject TEXT,               -- optional details
  channel TEXT,               -- 'citizen-app'/'admin-portal'/email
  status TEXT NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS pdpl_requests_status_idx ON pdpl_requests (status);
