
# NUSUJ v5.4 — Prod Wire‑up (Step-by-step)

1) **Terraform**
   ```bash
   cd infra/terraform
   terraform init
   terraform apply -var='bucket_name=nusuj-uploads-prod' -var='cdn_domain=cdn.example.com' -var='hosted_zone=example.com' -var='acm_cert_arn=arn:aws:acm:us-east-1:...'
   ```

2) **API env**
   - املأ `.env.prod` بالقيم الصحيحة (S3/CF/VAPID/Keycloak).

3) **DB migrations**
   ```bash
   psql $PGDATABASE -f db/init/002_push.sql
   psql $PGDATABASE -f db/init/003_pdpl_rights.sql
   ```

4) **Citizen App**
   - صفحة `/report` أصبحت ترفع مباشرة إلى S3 عبر presign.
   - صفحة `/notifications` تشترك في Web Push.
   - صفحة `/rights` و`/rights/request` لتفعيل حقوق PDPL.

5) **Grafana/Loki/Tempo**
   ```bash
   docker compose -f docker-compose.observability.yml up -d
   # استورد dashboard: observability/grafana/dashboards/nusuj_overview.json
   ```

6) **أمن**
   - طبّق HSTS/CSP عند CloudFront/ALB/NGINX.
   - فعّل WAF المُدار (مدمج في Terraform).

7) **هوية**
   - استورد `keycloak/realm-nusuj.json` في Keycloak.
   - حدّد الأدوار: admin/municipality/analyst/citizen وربط التطبيقات.

> بعد هذه الخطوات، يصبح مسار Go‑Live مكتملًا مع CDN + رفع آمن + إشعارات + لوحات مراقبة + حقوق PDPL.
