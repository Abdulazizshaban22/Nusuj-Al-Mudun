
'use client';
import { useState } from 'react';
const API_BASE = process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:4000';
export default function RightsRequest(){
  const [type,setType]=useState('access');
  const [subj,setSubj]=useState('');
  const [out,setOut]=useState<any>(null);
  async function send(){
    const r = await fetch(`${API_BASE}/privacy/rights/request`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({request_type:type,subject:subj,channel:'citizen-app'})});
    setOut(await r.json());
  }
  return (
    <main style={{padding:16, display:'grid', gap:8, maxWidth:520}}>
      <h2>طلب حق منحقوق البيانات (PDPL)</h2>
      <label>نوع الطلب:
        <select value={type} onChange={e=>setType(e.target.value)}>
          <option value="access">النفاذ إلى بياناتي</option>
          <option value="rectify">تصحيح بيانات</option>
          <option value="erase">محو بيانات</option>
          <option value="withdraw">سحب الموافقة</option>
        </select>
      </label>
      <label>شرح مختصر (اختياري):
        <textarea rows={4} value={subj} onChange={e=>setSubj(e.target.value)} />
      </label>
      <button onClick={send}>إرسال الطلب</button>
      <pre>{JSON.stringify(out,null,2)}</pre>
    </main>
  );
}
