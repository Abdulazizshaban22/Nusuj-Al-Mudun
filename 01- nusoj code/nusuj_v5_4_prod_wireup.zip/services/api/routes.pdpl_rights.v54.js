
import pkg from 'pg';
import express from 'express';
const { Pool } = pkg;
const pool = new Pool({
  host: process.env.PGHOST||'db',
  port: +(process.env.PGPORT||5432),
  user: process.env.PGUSER||'nusuj',
  password: process.env.PGPASSWORD||'nusuj',
  database: process.env.PGDATABASE||'nusuj',
  max: 10
});

const router = express.Router();

router.post('/privacy/rights/request', async (req,res)=>{
  const { request_type, subject, channel='citizen-app' } = req.body||{};
  if(!request_type) return res.status(400).json({error:'request_type required'});
  const r = await pool.query('INSERT INTO pdpl_requests (request_type,subject,channel) VALUES ($1,$2,$3) RETURNING id, status, created_at',[request_type, subject||null, channel]);
  res.json({ ok:true, id: r.rows[0].id, status: r.rows[0].status, created_at: r.rows[0].created_at });
});

router.get('/privacy/rights/requests', async (_req,res)=>{
  const r = await pool.query('SELECT id, request_type, subject, channel, status, created_at FROM pdpl_requests ORDER BY created_at DESC LIMIT 500');
  res.json({ items: r.rows });
});

router.post('/privacy/rights/requests/:id/status', async (req,res)=>{
  const id = Number(req.params.id||0);
  const { status } = req.body||{};
  if(!id or not status) return res.status(400).json({error:'id and status required'});
  await pool.query('UPDATE pdpl_requests SET status=$1, updated_at=now() WHERE id=$2',[status, id]);
  res.json({ ok:true });
});

export default router;
