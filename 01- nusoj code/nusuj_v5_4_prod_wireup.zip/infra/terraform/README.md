
# NUSUJ v5.4 — Terraform (S3 + CloudFront + WAF + DNS)

## Usage
```bash
cd infra/terraform
terraform init
terraform apply -var='bucket_name=nusuj-uploads-prod' -var='cdn_domain=cdn.example.com' -var='hosted_zone=example.com' -var='acm_cert_arn=arn:aws:acm:us-east-1:...:certificate/...'
```
- تأكد من أن شهادة ACM في **us-east-1** وتغطي `cdn.example.com`.
- بعد الإنشاء، استخدم المتغيرات التالية في تطبيقك:
  - `S3_BUCKET` = bucket_name
  - `CF_DOMAIN` = خرج `cloudfront_domain`
```
