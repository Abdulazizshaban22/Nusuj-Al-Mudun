
output "bucket_name"     { value = aws_s3_bucket.uploads.bucket }
output "cloudfront_id"   { value = aws_cloudfront_distribution.cdn.id }
output "cloudfront_domain" { value = aws_cloudfront_distribution.cdn.domain_name }
output "waf_arn"         { value = aws_wafv2_web_acl.cdn.arn }
