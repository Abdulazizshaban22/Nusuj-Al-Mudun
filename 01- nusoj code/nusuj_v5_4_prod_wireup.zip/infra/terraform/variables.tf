
variable "project"      { type = string  default = "nusuj" }
variable "region"       { type = string  default = "me-central-1" }
variable "bucket_name"  { type = string }
variable "cdn_domain"   { type = string }  # e.g., cdn.example.com
variable "hosted_zone"  { type = string }  # e.g., example.com
variable "acm_cert_arn" { type = string }  # us-east-1 certificate for CloudFront
