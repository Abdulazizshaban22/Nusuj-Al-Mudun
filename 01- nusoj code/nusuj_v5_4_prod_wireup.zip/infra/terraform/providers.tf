
terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.60"
    }
  }
}

provider "aws" {
  region = var.region
}

# CloudFront/ACM/WAF for CLOUDFRONT must be in us-east-1
provider "aws" {
  alias  = "use1"
  region = "us-east-1"
}
