
from flask import Flask, request, jsonify
from datetime import datetime, timedelta
import numpy as np

# events: list of {h3index, value, ts}
events = []
# neighbors: dict h3index -> list of neighbor h3 indexes (k-ring)
neighbors = {}

app = Flask(__name__)

@app.get('/health')
def health():
    return {'status':'ok'}

@app.post('/alerts/events/add')
def add_event():
    d = request.get_json(force=True)
    events.append({'h3index': d['h3index'], 'value': float(d['value']), 'ts': d.get('ts') or datetime.utcnow().isoformat()})
    return {'ok': True, 'count': len(events)}

@app.post('/st/gi_star')
def gi_star():
    """
    Request JSON:
    { "window":"7d", "ring":1, "neighbors": {"892...":["892..","892.."]} }
    """
    data = request.get_json(force=True) or {}
    ring = int(data.get('ring', 1))
    neigh = data.get('neighbors') or {}
    neighbors.update(neigh)

    window = data.get('window','7d')
    now = datetime.utcnow()
    if window.endswith('d'):
        dt = timedelta(days=int(window[:-1]))
    elif window.endswith('h'):
        dt = timedelta(hours=int(window[:-1]))
    else:
        dt = timedelta(days=7)
    t0 = now - dt

    # aggregate values per cell within time window
    vals = {}
    for e in events:
        ts = datetime.fromisoformat(e['ts'].split('Z')[0])
        if ts >= t0:
            vals.setdefault(e['h3index'], []).append(e['value'])
    if not vals:
        return jsonify({'since': t0.isoformat(), 'results': []})

    x = {k: float(np.mean(v)) for k,v in vals.items()}
    all_cells = list(x.keys())
    mu = np.mean(list(x.values()))
    sigma = np.std(list(x.values())) or 1.0

    results = []
    for i in all_cells:
        neigh_i = [i] + neighbors.get(i, [])
        w_sum = len(neigh_i) if len(neigh_i)>0 else 1
        s_val = sum([x.get(j, 0.0) for j in neigh_i])
        z = (s_val - w_sum * mu) / (sigma * (w_sum ** 0.5))
        results.append({'h3index': i, 'n': w_sum, 'sum': s_val, 'z': float(z)})
    return jsonify({'since': t0.isoformat(), 'window': window, 'ring': ring, 'results': results})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
