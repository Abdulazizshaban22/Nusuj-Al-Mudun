# NUSUJ (نُسُج) — v4.8

## الجديد في v4.8
- Queryables + Conformance + Capabilities
- CQL2-JSON وCQL2 النصّي (subset)
- STAC API + Search (bbox+datetime)
- Story Maps seed (YAML)
- Gi* مبسّط يقبل مصفوفة مجاورات (بدون PySAL)

> لحساب Gi* رسميًّا في الإنتاج، اربط PySAL + H3 كما في التوثيق.
