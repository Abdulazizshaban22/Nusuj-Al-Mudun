import jwt, { JwtHeader } from 'jsonwebtoken';
import jwksClient from 'jwks-rsa';

const jwksUri = process.env.KEYCLOAK_JWKS_URL || '';
const client = jwksUri ? jwksClient({ jwksUri, cache: true, rateLimit: true }) : null;

async function getKey(header: JwtHeader) {
  if (!client || !header.kid) throw new Error('JWKS not configured');
  const key: any = await client.getSigningKey(header.kid);
  return key.getPublicKey();
}

export async function verifyToken(token: string): Promise<any> {
  if (!jwksUri) throw new Error('Missing KEYCLOAK_JWKS_URL');
  return new Promise((resolve, reject) => {
    jwt.verify(token, getKey as any, { algorithms: ['RS256'] }, (err, decoded) => {
      if (err) return reject(err);
      resolve(decoded);
    });
  });
}

export function hasRole(payload: any, role: string): boolean {
  const roles = payload?.realm_access?.roles || [];
  return roles.includes(role);
}