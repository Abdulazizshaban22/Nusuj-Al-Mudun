from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import numpy as np, os, json, yaml

from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST
from fastapi.responses import Response

from h3 import h3
import psycopg
from esda import G_Local
import libpysal

app = FastAPI(title="NASIJ ETL", version="4.3.0")

REQS = Counter("etl_requests_total", "Total requests", ["endpoint"])
LAT  = Histogram("etl_request_seconds", "Latency seconds", ["endpoint"])

DB_URL = os.environ.get("DATABASE_URL")

@app.get("/health")
def health():
    REQS.labels(endpoint="/health").inc()
    return {"status":"ok","service":"etl","version":"4.3.0"}

@app.get("/metrics")
def metrics():
    data = generate_latest()
    return Response(content=data, media_type=CONTENT_TYPE_LATEST)

# ----- H3 / Hotspots -----
class H3IndexIn(BaseModel):
    lat: float; lng: float; res: int
@app.post("/h3/index")
def h3_index(inp: H3IndexIn):
    REQS.labels(endpoint="/h3/index").inc()
    if not (0 <= inp.res <= 15): raise HTTPException(400, "res must be 0..15")
    return {"h3index": h3.geo_to_h3(inp.lat, inp.lng, inp.res)}

class H3HotspotItem(BaseModel):
    h3index: str; value: float
class H3HotspotIn(BaseModel):
    items: List[H3HotspotItem]; ring: int = 1
@app.post("/h3/hotspots")
def h3_hotspots(inp: H3HotspotIn):
    REQS.labels(endpoint="/h3/hotspots").inc()
    cells = [it.h3index for it in inp.items]; values = np.array([it.value for it in inp.items])
    if len(cells) != len(set(cells)): raise HTTPException(400, "duplicate h3index")
    neighbors = {}; cellset = set(cells)
    for c in cells:
        neigh = set(h3.k_ring(c, inp.ring)) & cellset
        neighbors[c] = list(neigh)
    w = libpysal.weights.W(neighbors, silence_warnings=True); w.transform='R'
    g = G_Local(values, w, star=True)
    out = [{"h3index": c, "z": float(z), "p": float(p)} for c, z, p in zip(cells, g.Zs, g.p_sim)]
    out.sort(key=lambda r: abs(r["z"]), reverse=True)
    return {"n": len(out), "results": out}

# ----- GeoJSON ingest -----
class Feature(BaseModel):
    type: str; geometry: Dict[str, Any]; properties: Optional[Dict[str, Any]] = None
class FeatureCollection(BaseModel):
    type: str; features: List[Feature]; source: Optional[str] = "upload"
@app.post("/geojson/ingest")
def geojson_ingest(fc: FeatureCollection):
    REQS.labels(endpoint="/geojson/ingest").inc()
    if fc.type != "FeatureCollection": raise HTTPException(400, "type must be FeatureCollection")
    if not DB_URL: raise HTTPException(500, "DATABASE_URL not set")
    n=0
    with psycopg.connect(DB_URL) as con:
        with con.cursor() as cur:
            for f in fc.features:
                geom = json.dumps(f.geometry); props = json.dumps(f.properties or {})
                cur.execute("INSERT INTO urban.features (source, props, geom) VALUES (%s,%s,ST_SetSRID(ST_GeomFromGeoJSON(%s),4326))",
                            (fc.source or "upload", props, geom)); n+=1
        con.commit()
    return {"inserted": n}

# ----- Alerts (simple threshold rules) -----
_alert_rules: List[Dict[str, Any]] = []
class Rule(BaseModel):
    name: str
    metric: str  # e.g., 'gi_z' or 'value'
    op: str      # '>' or '<'
    threshold: float
@app.post("/alerts/rules")
def add_rule(rule: Rule):
    REQS.labels(endpoint="/alerts/rules").inc()
    if rule.op not in ('>','<'): raise HTTPException(400, "op must be '>' or '<'")
    _alert_rules.append(rule.dict())
    return {"rules": _alert_rules}

class EvaluateIn(BaseModel):
    items: List[H3HotspotItem]  # reuse {h3index, value}
@app.post("/alerts/evaluate")
def evaluate(items: EvaluateIn):
    REQS.labels(endpoint="/alerts/evaluate").inc()
    alerts = []
    for r in _alert_rules:
        for it in items.items:
            val = it.value
            ok = (val > r["threshold"]) if r["op"] == ">" else (val < r["threshold"])
            if ok:
                alerts.append({"rule": r["name"], "h3index": it.h3index, "value": val})
    return {"alerts": alerts}