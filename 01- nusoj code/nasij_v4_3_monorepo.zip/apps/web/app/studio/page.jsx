'use client';
import { useState } from 'react';

export default function Studio(){
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('');
  const onUpload = async () => {
    if(!file) return;
    const text = await file.text();
    try{
      const fc = JSON.parse(text);
      const res = await fetch(process.env.ETL_BASE_URL + '/geojson/ingest', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(fc)
      });
      const out = await res.json();
      setStatus(JSON.stringify(out, null, 2));
    }catch(e){ setStatus('Bad GeoJSON'); }
  };
  return (
    <main style={{padding:24,fontFamily:"ui-sans-serif"}}>
      <h2>NASIJ Studio — رفع GeoJSON</h2>
      <input type="file" accept=".json,.geojson" onChange={e=>setFile(e.target.files?.[0]||null)} />
      <button onClick={onUpload} style={{marginLeft:12}}>رفع ومعالجة</button>
      <pre style={{marginTop:16}}>{status}</pre>
      <p style={{marginTop:24}}>صيغة مطلوبة: <code>FeatureCollection</code> وفق RFC 7946.</p>
    </main>
  );
}