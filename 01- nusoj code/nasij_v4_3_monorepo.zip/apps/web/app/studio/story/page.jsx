'use client';
import { useState } from 'react';

const SAMPLE = `name: "قصة حديقة الحي"
sections:
  - title: "المقدمة"
    camera: { center: [46.6753, 24.7136], zoom: 12 }
    layers:
      - type: "collection"
        id: "features"
        filter: { source: "upload" }
  - title: "البلاغات"
    camera: { center: [46.71, 24.72], zoom: 13 }
    layers:
      - type: "collection"
        id: "open311_requests"`;

export default function StoryEditor(){
  const [yaml, setYaml] = useState(SAMPLE);
  const [name, setName] = useState("قصة حديقة الحي");
  const [status, setStatus] = useState('');
  async function save(){
    const res = await fetch(process.env.API_BASE_URL + '/story/ingest', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({name, yaml})
    });
    const out = await res.json();
    setStatus(JSON.stringify(out, null, 2));
  }
  return (
    <main style={{padding:24,fontFamily:"ui-sans-serif"}}>
      <h2>Story Maps — محرّر YAML</h2>
      <p>اكتب السيناريو ثم احفظه. لاحقًا يمكننا توليد العرض التفاعلي تلقائيًا.</p>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:16}}>
        <div>
          <label>اسم القصة</label><br/>
          <input value={name} onChange={e=>setName(e.target.value)} style={{width:'100%'}}/>
          <label style={{display:'block',marginTop:8}}>YAML</label>
          <textarea value={yaml} onChange={e=>setYaml(e.target.value)} style={{width:'100%',height:280}} />
          <button onClick={save} style={{marginTop:8}}>حفظ القصة</button>
        </div>
        <pre>{status}</pre>
      </div>
    </main>
  );
}