# NASIJ v4.3 — Story Maps + OGC Features (Read) + Alerts
هذه النسخة تضيف:
- **Story Maps**: إدخال سيناريوهات عبر YAML وتخزينها (urban.stories) + صفحة واجهة `/studio/story`.
- **OGC API-Features (قراءة)**: `/ogc/collections` و`/ogc/collections/{id}/items` لمجموعات: `features`, `open311_requests`.
- **Alerts (قواعد بسيطة)**: نقطة `/alerts/rules` في ETL لتسجيل قواعد عتبات (تجريبية) وتقييمها على بيانات H3 أو القيم الواردة.
- استمرارية: Open311 + GeoJSON ingest + RBAC (JWKS) + Prometheus/Grafana.

## التشغيل
```bash
cp .env.example .env
docker compose up -d --build
# Web:       http://localhost:3000
# API:       http://localhost:4000
# ETL:       http://localhost:5000/docs
# Prometheus http://localhost:9090
# Grafana    http://localhost:3001 (admin/admin)
```